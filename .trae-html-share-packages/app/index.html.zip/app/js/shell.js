/* ============================================================
   绿角犀 Office · 应用外壳 (Shell)
   仪表盘 / 多标签 / 标签页功能区调度 / 标题栏 / 状态栏 / 文件后台 /
   主题 / 命令面板 / 导入导出 / 自动保存
   ============================================================ */
(function (global) {
  "use strict";
  // TODO: [坑-shell-openDoc-无await] 预防: openDoc 加 await + 进度条 step 文字每 5% 更新一次 (见 issues.md)
  // TODO: [坑-Promise-无timeout] 预防: Promise 链首尾加 _withTimeout 兜底
  // TODO: [坑-fileassoc-hardcoded-absolute] 预防: fileAssoc 路径用 OS.path 拼接别裸写绝对路径
  // TODO: [坑-order-inventory-approval-residue] 预防: import 语句定期扫 grep 残留模块名
  // TODO: [坑-tasks-settle-step] 预防: Tasks.run settle 回调里显式 reporter.step(xx, 1) 刷 100%
  // TODO: [坑-shortcut-test-fragile] 预防: 快捷键矩阵用枚举名匹配别用字符串 include
  const OS = global.OS;
  // ========== 🩺 诊断工具：phase 心跳 + 带 timeout 的 await ==========
  function _withTimeout(promise, ms, label) {
    return new Promise((resolve, reject) => {
      let done = false;
      const to = setTimeout(() => {
        if (done) return; done = true;
        console.error('[TIMEOUT]', label, '卡住已 ' + (ms / 1000) + 's — 这很可能就是你说的卡死');
        reject(new Error((label || "async op") + " 超时 (" + (ms / 1000) + "s) — 这就是卡死的位置"));
      }, ms);
      promise.then(
        v => { if (done) return; done = true; clearTimeout(to); resolve(v); },
        e => { if (done) return; done = true; clearTimeout(to); reject(e); }
      );
    });
  }
  function _phase(name, promise, ms) {
    window.$phase && window.$phase.start(name);
    const t0 = performance.now();
    return _withTimeout(promise, ms || 15000, name).then(
      v => { window.$phase && window.$phase.done(name); console.log('[PHASE]', name, Math.round(performance.now() - t0) + 'ms'); return v; },
      e => { window.$phase && window.$phase.done(name); console.error('[PHASE-ERR]', name, e.message); throw e; }
    );
  }
  console.log('[DIAG] shell phase 工具就绪 — await _phase("name", promise, 15000)');
  // 历史坑预防 TODO（ledger-precheck 强制要求）：
  // TODO: [坑-toast-容器未挂载到-body] 预防：OS.util.toast 需确保 toast 容器已 appendChild 到 body
  // TODO: [坑-fileassoc-硬编码绝对路径跨环境炸] 预防：mimeFor / 文件关联一律按 ext 查表，不硬编码 C:\ 路径
  // TODO: [坑-订单-库存-审批残留引用导致白屏] 预防：功能下线需六步走（UI→JS→CSS→事件→路由→grep）
  const $ = s => document.querySelector(s);
  const ICON = () => OS.icons;

  let tabs = [];           // { id, doc, instance, dirty }
  let activeId = null;
  let saveTimer = null;
  let zoom = 100;
  let _tabSwitcher = null; // Ctrl+Tab 可视化弹窗状态
  let _recentlyClosed = []; // Ctrl+Shift+T 重开最近关闭（最多 20 条）

  // TODO: [坑-shell-on-scope] 预防：_on 必须在 IIFE 顶层声明，所有函数共享；禁止只在某个函数内部声明后被其他函数调用
  let _Listeners = [];
  const _on = (el, evt, fn, opts) => { if (el && el.addEventListener) { el.addEventListener(evt, fn, opts); _Listeners.push({ el, evt, fn, opts }); } };
  const _offAll = () => { for (const { el, evt, fn, opts } of _Listeners) { try { el.removeEventListener(evt, fn, opts); } catch (e) {} } _Listeners = []; };

  function activeTab() { return tabs.find(t => t.id === activeId); }
  function activeInst() { const t = activeTab(); return t && t.instance; }

  /* ---------------- 主导航：工作台 / 我的 ---------------- */
  const TOPNAV_PANELS = ["profile"];
  const TOPNAV_VIEWS = {
    profile: { title: "我的", desc: "账户、设置与使用偏好", tiles: [
      { k: "account", n: "账户与存储", d: "登录状态、50MB 个人云空间" },
      { k: "prefs", n: "偏好设置", d: "主题、自动保存等本地选项" },
      { k: "about", n: "关于", d: "版本与兼容信息" }] }
  };

  function _navHighlight(view) {
    document.querySelectorAll(".app-nav-item").forEach(b =>
      b.classList.toggle("active", b.dataset.view === view));
  }
  function _toWorkbenchNav() { // 编辑态 / 返回工作台时，面板隐藏并将高亮复位到工作台
    TOPNAV_PANELS.forEach(v => { const p = $("#panel-" + v); if (p) p.hidden = true; });
    _navHighlight("workbench");
  }
  function renderTopPanel(view) {
    const el = $("#panel-" + view); if (!el) return;
    const v = TOPNAV_VIEWS[view];
    const tiles = (v.tiles || []).map(t =>
      `<div class="panel-tile" data-panel-action="${view}:${t.k}"><div class="pt-name">${t.n}</div><div class="pt-desc">${t.d}</div></div>`).join("");
    el.innerHTML = `<div class="panel-head"><h2>${v.title}</h2><span class="muted">${v.desc}</span></div>` +
      `<div class="panel-card"><div class="panel-grid">${tiles}</div><div class="panel-empty" style="margin-top:12px">该板块为框架首发（骨架），业务数据与云端对接将在后续版本接入。</div></div>`;
    el.querySelectorAll(".panel-tile").forEach(tile => {
      tile.addEventListener("click", () => {
        const a = tile.dataset.panelAction;
        if (a === "profile:account") { openAccount && openAccount(); return; }
        OS.toast("「" + tile.querySelector(".pt-name").textContent + "」功能建设中", "");
      });
    });
  }
  function switchTopNav(view) {
    TOPNAV_PANELS.forEach(v => { const p = $("#panel-" + v); if (p) p.hidden = true; });
    _navHighlight(view);
    $("#editor").hidden = true;
    $("#ribbon-host") && ($("#ribbon-host").hidden = true);
    if (view === "workbench") {
      $("#dashboard").hidden = false;
    } else {
      $("#dashboard").hidden = true;
      const p = $("#panel-" + view);
      if (p) { if (!p.dataset.rendered) { renderTopPanel(view); p.dataset.rendered = "1"; } p.hidden = false; }
    }
    closeBackstage && closeBackstage();
  }
  function initTopNav() {
    const nav = $("#app-nav"); if (!nav) return;
    nav.addEventListener("click", e => {
      const b = e.target.closest(".app-nav-item"); if (!b) return;
      switchTopNav(b.dataset.view);
    });
  }

  async function boot() {
    // TODO: [坑-os-undefined] 预防：boot 入口先 await store.init → store.init 内部调 OS._markReady() resolve OS.ready
    // 这样后续所有跨模块调用（OS.store/OS.auth/OS.AI）都在已就绪状态下执行
    try { await OS.store.init(); } catch (e) { console.error("[Shell] store.init 失败:", e); }

    // —— PWA beforeinstallprompt 捕获（showAbout 里「📱 安装」按钮会用）——
    let _installPrompt = null;
    window.addEventListener("beforeinstallprompt", e => {
      e.preventDefault();
      _installPrompt = e;
      try { OS.settings.set("pwaInstallAvailable", true); } catch(e) {}
    });
    window.addEventListener("appinstalled", () => { _installPrompt = null; try { OS.settings.set("pwaInstallAvailable", false); } catch(e) {} });
    // 暴露给 showAbout 用
    window.__installPrompt = () => _installPrompt;
    // 顶栏图标注入
    $("#qa-save").innerHTML = ICON().svg("save", 18);
    $("#qa-undo").innerHTML = ICON().svg("undo", 18);
    $("#qa-redo").innerHTML = ICON().svg("redo", 18);
    $("#btn-cmd").innerHTML = ICON().svg("search", 18);
    $("#btn-theme").innerHTML = ICON().svg("contrast", 18);
    $("#btn-account").innerHTML = ICON().svg("user", 18);

    // 还原 AI 云端配置（仅本机持久化）
    try { const saved = OS.settings.get("aiProvider"); if (saved && saved.endpoint) OS.AI.setProvider(saved); } catch (e) { console.error("[Shell] 操作失败:", e); }

    // AI 助手入口
    $("#btn-ai").innerHTML = ICON().svg("spark", 18);
    $("#btn-ai").addEventListener("click", openAI);
    $("#ai-close").addEventListener("click", closeAI);
    $("#ai-send").addEventListener("click", aiSend);
    $("#ai-text").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); aiSend(); } });

    // 登录设定：默认不强制登录（游客直接进入）；开启「启动时要求登录」后未登录才拦截
    const mustLogin = !!(OS.AuthPolicy && OS.AuthPolicy.shouldGate()) && !OS.auth.isLoggedIn();
    if (mustLogin) showLogin();
    else enterApp();

    initTopNav(); // 主导航：工作台 / 订单 / 库存 / 审批 / 我的

    // 「我的」板块内的账户按钮 → 打开账户抽屉
    _on(document, "app:open-account", () => openAccount());

    if (global.pdfjsLib) global.pdfjsLib.GlobalWorkerOptions.workerSrc = "vendor/pdf.worker.min.js";
    // 原生壳（Electron / Capacitor / HarmonyOS WebView）下跳过 Service Worker 注册，避免离线双缓存与 file:// 协议报错
    var isNativeShell = /Electron/i.test(navigator.userAgent) || (global.Capacitor && global.Capacitor.isNativePlatform && global.Capacitor.isNativePlatform());
    if (!isNativeShell && location.protocol.startsWith("http") && "serviceWorker" in navigator)
      navigator.serviceWorker.register("sw.js").catch(e => console.error("[Shell] 操作失败:", e));

    // 顶栏 / 快速访问
    $("#btn-theme").addEventListener("click", () => OS.theme.toggle());
    $("#qa-save").addEventListener("click", () => saveNow());
    $("#qa-undo").addEventListener("click", () => activeInst() && activeInst().undo && activeInst().undo());
    $("#qa-redo").addEventListener("click", () => activeInst() && activeInst().redo && activeInst().redo());
    $("#btn-account").addEventListener("click", openAccount);
    $("#btn-cmd").addEventListener("click", openCmd);
    $("#btn-open").addEventListener("click", () => $("#file-input").click());
    $("#file-input").addEventListener("change", onFile);

    // 原生桌面壳：接收主进程从文件关联（双击/默认打开方式）推来的文件，直接打开
    if (global.electronAPI) {
      // 主进程推来的文件（second-instance / open-file）：转为 File 走统一导入
      const openPayload = (payload) => {
        try {
          if (!payload || !payload.base64) return;
          const ext = payload.ext || (payload.name || "").split(".").pop() || "";
          const blob = b64ToBlob(payload.base64, mimeFor(ext));
          importFileObj(new File([blob], payload.name || ("document" + ext), { type: blob.type }))
            .catch(e => { console.error("[Shell] importFileObj 异常:", e); OS.toast("导入失败：" + (e && e.message || e), "err"); });
        } catch (e) { console.error("app:open-file 处理失败:", e); OS.toast("打开文件失败：" + (e && e.message || e), "err"); }
      };
      global.electronAPI.on("app:open-file", openPayload);
      // 就绪握手 + 队列兜底：通知主进程前端已可接收文件，并拉取握手前排队的文档（不依赖易失效的 did-finish-load）
      if (global.electronAPI.invoke) {
        global.electronAPI.invoke("app:renderer-ready").then(() => global.electronAPI.invoke("app:pending-files")).then((q) => {
          if (q && q.length) q.forEach(openPayload);
        }).catch(e => console.error("[Shell] 操作失败:", e));
      }
    }

    // 登录页交互（绑定一次）：统一账号（本地离线 + 云端同步）
    $("#login-btn").addEventListener("click", onLogin);
    $("#register-btn").addEventListener("click", onRegister);
    const guestBtn = $("#guest-btn");
    if (guestBtn) guestBtn.addEventListener("click", () => { hideLogin(); enterApp(); });

    // 开始页模板搜索（实时过滤画廊）
    const tplSearch = $("#tpl-search");
    if (tplSearch) tplSearch.addEventListener("input", e => renderGallery(e.target.value));

    document.addEventListener("click", e => {
      const n = e.target.closest("[data-new]");
      if (n) newDoc(n.dataset.new);
      const t = e.target.closest("[data-tpl]");
      if (t) newDoc(t.dataset.module, t.dataset.tpl);
    });

    document.addEventListener("keydown", e => {
    const k = e.key.toLowerCase();
    // Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y — 撤销重做（路由到 OS.Undo）
    if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && k === "z") { e.preventDefault(); OS.Undo.undo(); return; }
    if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.shiftKey && k === "z" || k === "y")) { e.preventDefault(); OS.Undo.redo(); return; }
    // 不拦截 input/textarea 原生输入快捷键
    const tag = (e.target && e.target.tagName) || "";
    if (tag === "INPUT" || tag === "TEXTAREA") return;
      // Ctrl+Tab / Ctrl+Shift+Tab — 可视化切标签弹窗（按住不放选择，松开切换）
      if (e.ctrlKey && !e.altKey && !e.metaKey && k === "tab") {
        e.preventDefault();
        if (tabs.length < 2) return;
        if (!_tabSwitcher) _tswOpen();
        else _tswMove(e.shiftKey ? -1 : 1);
      }
      // Ctrl+N — 新建（Writer 优先，因为最常用）
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === "n") { e.preventDefault(); newDoc("writer"); }
      // Ctrl+O — 打开文件
      else if ((e.ctrlKey || e.metaKey) && k === "o") { e.preventDefault(); $("#file-input").click(); }
      // Ctrl+W — 关闭当前标签
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === "w") { e.preventDefault(); const t = activeTab(); if (t) closeTab(t.id); else closeBackstage && closeBackstage(); }
      // Ctrl+P — 打印
      else if ((e.ctrlKey || e.metaKey) && k === "p") { e.preventDefault(); const t = activeTab(); if (t && t.instance && t.instance.exportAs) t.instance.exportAs("pdf"); else window.print(); }
      else if ((e.ctrlKey || e.metaKey) && k === "k") { e.preventDefault(); openCmd(); }
      else if ((e.ctrlKey || e.metaKey) && k === "s") { e.preventDefault(); saveNow(); }
      else if ((e.ctrlKey || e.metaKey) && k === "e") { e.preventDefault(); showExportMenu(); }
      else if ((e.ctrlKey || e.metaKey) && k === "h" && e.shiftKey) { e.preventDefault(); goHome(); }
      else if ((e.ctrlKey || e.metaKey) && k === "h" && !e.shiftKey) { e.preventDefault(); openReplace(); }
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === "f") { e.preventDefault(); const t = activeTab(); if (t && t.instance && typeof t.instance.openFindPanel === "function") t.instance.openFindPanel("find"); else openSearch(); }
      else if ((e.ctrlKey || e.metaKey) && e.shiftKey && k === "m") { e.preventDefault(); const t = activeTab(); if (t && t.instance && typeof t.instance.addComment === "function") t.instance.addComment(); else OS.toast("批注仅在表格中可用", "warn"); }
      else if ((e.ctrlKey || e.metaKey) && e.shiftKey && k === "f") { e.preventDefault(); openSearch(); }
      // Ctrl+Q — 退出应用（Electron）
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === "q") { e.preventDefault(); if (global.electronAPI && global.electronAPI.invoke) { global.electronAPI.invoke("app:quit"); } else { window.close(); } }
      // Ctrl+Shift+T — 重开最近关闭标签
      else if ((e.ctrlKey || e.metaKey) && e.shiftKey && k === "t") { e.preventDefault(); reopenRecentlyClosed(); }
      // F5 — 刷新开发者模式（重载窗口）
      else if (!e.ctrlKey && !e.altKey && k === "f5") { e.preventDefault(); if (global.electronAPI && global.electronAPI.invoke) { global.electronAPI.invoke("app:reload"); } else { location.reload(); } }
      // Ctrl+R — 刷新（同 F5）
      else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && k === "r") { e.preventDefault(); if (global.electronAPI && global.electronAPI.invoke) { global.electronAPI.invoke("app:reload"); } else { location.reload(); } }
      // F1 — 帮助（打开文档 / 关于弹窗）
      else if (!e.ctrlKey && !e.altKey && k === "f1") { e.preventDefault(); showAbout(); }
      else if (e.altKey && k === "t") { e.preventDefault(); OS.Tasks && OS.Tasks.togglePanel(); }
      else if ((e.ctrlKey || e.metaKey) && e.shiftKey && k === "a") { e.preventDefault(); openAI(); }
      else if (e.key === "Escape") closeOverlays();
    });

    OS.bus.on("doc-renamed", doc => { const t = tabs.find(x => x.id === doc.id); if (t) renderTab(t); });
  }

  /* ---------------- 仪表盘 / 开始页 ---------------- */
  /* 模板画廊渲染：支持搜索过滤 + 收藏分组 */
  function renderGallery(rawQuery) {
    const gallery = $("#tpl-gallery");
    if (!gallery) return;
    gallery.innerHTML = "";
    const q = (rawQuery || "").trim().toLowerCase();
    const T = OS.Templates || { list: [], groups: [], byId: () => null };
    const modLabel = {};
    T.groups.forEach(g => { modLabel[g.module] = g.label; });

    function makeCard(tpl) {
      const faved = OS.Favorites.isFav(tpl.id);
      const card = document.createElement("button");
      card.className = "tpl-card" + (faved ? " is-fav" : "") + (tpl.isCustom ? " is-custom" : "");
      card.dataset.tpl = tpl.id;
      card.dataset.module = tpl.module;
      card.innerHTML =
        `<button class="tpl-star ${faved ? "on" : ""}" type="button" title="${faved ? "取消收藏" : "收藏模板"}" aria-label="收藏模板">${faved ? "★" : "☆"}</button>` +
        (tpl.isCustom ? `<button class="tpl-del" type="button" title="删除模板" aria-label="删除模板">🗑</button>` : "") +
        `<div class="tpl-thumb">${tpl.thumb || ""}</div>` +
        `<div class="tpl-meta"><div class="tpl-name">${OS.util.escapeHtml(tpl.name)}</div>` +
        `<div class="tpl-desc">${OS.util.escapeHtml(tpl.desc)}</div></div>`;
      card.querySelector(".tpl-star").addEventListener("click", e => {
        e.stopPropagation(); // 避免触发「新建文档」
        OS.Favorites.toggle(tpl.id);
        renderGallery($("#tpl-search") ? $("#tpl-search").value : "");
      });
      if (tpl.isCustom) {
        card.querySelector(".tpl-del").addEventListener("click", e => {
          e.stopPropagation();
          if (confirm(`删除模板「${tpl.name}」？此操作不可撤销。`)) {
            OS.CustomTemplates.remove(tpl.id);
            renderGallery($("#tpl-search") ? $("#tpl-search").value : "");
            OS.toast("已删除模板", "ok");
          }
        });
      }
      return card;
    }

    function appendGroup(label, items, fav) {
      if (!items.length) return;
      const wrap = document.createElement("div");
      wrap.className = "tpl-group" + (fav ? " fav" : "");
      const head = document.createElement("div");
      head.className = "tpl-group-head" + (fav ? " fav" : "");
      head.textContent = label;
      wrap.appendChild(head);
      const row = document.createElement("div");
      row.className = "tpl-row";
      items.forEach(t => row.appendChild(makeCard(t)));
      wrap.appendChild(row);
      gallery.appendChild(wrap);
    }

    const customs = OS.CustomTemplates ? OS.CustomTemplates.all() : [];

    if (q) {
      const merged = T.list.concat(customs);
      const filtered = merged.filter(t =>
        t.name.toLowerCase().includes(q) ||
        t.desc.toLowerCase().includes(q) ||
        (modLabel[t.module] || "").toLowerCase().includes(q) ||
        (t.isCustom && "自定义".includes(q)));
      if (filtered.length) appendGroup("搜索结果", filtered, false);
      else {
        const empty = document.createElement("p");
        empty.className = "tpl-empty";
        empty.textContent = "没有匹配“" + (rawQuery || "").trim() + "”的模板";
        gallery.appendChild(empty);
      }
      return;
    }

    // 无搜索词：收藏分组置顶 + 自定义分组 + 模块分组（已收藏/自定义项从原分组隐藏，避免重复）
    const favs = OS.Favorites.all().map(id => T.byId(id)).filter(Boolean);
    appendGroup("★ 收藏", favs, true);
    appendGroup("自定义", customs.filter(t => !OS.Favorites.isFav(t.id)), false);
    T.groups.forEach(g => appendGroup(g.label, g.items.filter(t => !OS.Favorites.isFav(t.id)), false));
  }

  async function renderDashboard() {
    renderGallery($("#tpl-search") ? $("#tpl-search").value : "");
    // 最近文档
    const docs = await OS.store.list();
    const grid = $("#recent-grid");
    grid.innerHTML = "";
    $("#recent-count").textContent = docs.length ? `（${docs.length}）` : "";
    $("#recent-empty").hidden = docs.length > 0;
    docs.forEach(d => grid.appendChild(docCard(d)));
  }

  function docCard(d) {
    const info = OS.TYPE_INFO[d.type] || { ico: "📄", name: d.type, accent: "#64748b" };
    const accent = (OS.Templates && OS.Templates.list.find(t => t.module === d.type && t.id.endsWith("-blank"))
      ? OS.Templates.list.find(t => t.module === d.type && t.id.endsWith("-blank")).accent : "#64748b");
    const el = document.createElement("div");
    el.className = "doc-card"; el.dataset.id = d.id;
    el.innerHTML = `<div class="doc-ico" style="--doc-accent:${accent}">${info.ico}</div>
      <div class="doc-name">${OS.util.escapeHtml(d.name)}</div>
      <div class="doc-meta">${info.name} · ${OS.util.fmtTime(d.updatedAt)} · ${OS.util.fmtSize(d.size || 0)}</div>
      <button class="doc-del" title="删除" aria-label="删除">🗑</button>`;
    _on(el, "click", () => openDoc(d));
    el.querySelector(".doc-del").addEventListener("click", async e => {
      e.stopPropagation();
      if (confirm(`确定删除「${d.name}」？此操作不可撤销。`)) {
        await OS.store.remove(d.id); renderDashboard(); OS.toast("已删除", "ok");
      }
    });
    return el;
  }

  /* ---------------- 文档打开/新建 ---------------- */
  async function newDoc(type, templateId) {
    window.$phase && window.$phase.start('newDoc.create');
    const doc = await OS.store.create({ type });
    window.$phase && window.$phase.done('newDoc.create');
    if (templateId && OS.Templates) {
      const tpl = OS.Templates.byId(templateId);
      if (tpl) {
        window.$phase && window.$phase.start('newDoc.template');
        doc.data = tpl.build();
        doc.name = tpl.name;
        doc.compat = "A";
        await OS.store.put(doc);
        window.$phase && window.$phase.done('newDoc.template');
      }
    }
    window.$phase && window.$phase.start('newDoc.openDoc');
    await openDoc(doc);
    window.$phase && window.$phase.done('newDoc.openDoc');
  }

  async function openDoc(doc) {
    const existing = tabs.find(t => t.id === doc.id);
    if (existing) { activate(existing); return; }
    _toWorkbenchNav();
    $("#dashboard").hidden = true;
    $("#editor").hidden = false;
    $("#ribbon-host").hidden = false;
    $("#statusbar").hidden = false;

    const hostEl = $("#module-host");
    $("#ribbon-host").innerHTML = "";

    // **分帧渲染**：大节点数（>500）mindmap 的 mount 会堵主线程 500ms+
    // 用 rAF 让事件循环先处理完 UI 更新（任务面板 100% 消失、toast 出现），再渲染
    const nodes = doc.data?.nodes?.length || 0;
    const needSplit = nodes > 500;

    const inst = OS.modules[doc.type].mount(hostEl, doc, {
      ribbonHost: $("#ribbon-host"),
      markDirty,
      saveNow,
      openBackstage,
      // 给 mount 传一个 _split: true 让它内部 layoutMap 和 render 之间也 rAF
      _split: needSplit
    });

    const t = { id: doc.id, doc, instance: inst, dirty: false };
    t.wrap = hostEl.lastElementChild;
    tabs.push(t);
    renderTabbar();                   // 🔥 重建 tabbar DOM — 用户才能看到 tab！
    OS.Undo.bindModule(doc.id, inst);
    activate(t);
    OS.toast(`已打开：${doc.name}`, "ok");
  }

  function activate(t) {
    activeId = t.id;
    OS.Undo.activate(t.id); // Undo 调度器也要切激活 tab
    // 仅显示当前文档的模块容器，隐藏其余（修复多标签堆叠遮挡）
    tabs.forEach(x => { if (x.wrap) x.wrap.style.display = (x.id === t.id) ? "" : "none"; });
    document.querySelectorAll(".tab").forEach(el => el.classList.toggle("active", el.dataset.id === t.id));

    // 功能区切换
    const host = $("#ribbon-host"); host.innerHTML = "";
    const ribbon = t.instance.ribbon || t.instance._ribbon;
    if (ribbon) host.appendChild(ribbon.el || ribbon);
    host.hidden = !ribbon;

    // 兼容徽章 + 标题
    const badge = $("#compat-badge");
    if (t.doc.compat && OS.COMPAT[t.doc.compat]) {
      badge.hidden = false; badge.textContent = OS.COMPAT[t.doc.compat].label;
      badge.style.background = OS.COMPAT[t.doc.compat].color
        .replace("var(--ok)", "#0e7c3a").replace("var(--warn)", "#b9700f").replace("var(--danger)", "#c4312b");
      badge.style.color = "#fff";
    } else badge.hidden = true;

    updateTitle();
    renderStatusbar();
    zoom = 100; applyZoom(0);
  }

  function updateTitle() {
    const t = activeTab(); if (!t) { $("#doc-title").textContent = ""; return; }
    $("#doc-title").innerHTML = OS.util.escapeHtml(t.doc.name) + (t.dirty ? '<span class="dirty">●</span>' : "");
    document.title = t.doc.name + " · 绿角犀 Office";
  }

  function closeTab(id) {
    const i = tabs.findIndex(t => t.id === id); if (i < 0) return;
    const t = tabs[i];
    if (t.dirty && !confirm(`「${t.doc.name}」有未保存改动，仍要关闭？`)) return;
    // 存到最近关闭历史（Ctrl+Shift+T 用）
    _recentlyClosed.push({ doc: JSON.parse(JSON.stringify(t.doc)), timestamp: Date.now() });
    if (_recentlyClosed.length > 20) _recentlyClosed.shift();
    if (t.instance.destroy) t.instance.destroy();
    OS.Undo.unbindModule(id); // 从 Undo 调度器解绑
    tabs.splice(i, 1);
    if (activeId === id) {
      activeId = tabs.length ? tabs[tabs.length - 1].id : null;
      if (activeId) activate(tabs.find(t => t.id === activeId));
      else goHome();
    }
    renderTabbar();
  }
  // Ctrl+Shift+T 重开最近关闭
  function reopenRecentlyClosed() {
    if (!_recentlyClosed.length) { OS.toast("没有可恢复的最近关闭标签", "info"); return; }
    const entry = _recentlyClosed.pop();
    openDoc(entry.doc);
  }

  function renderTabbar() {
    const bar = $("#tabbar"); bar.innerHTML = "";
    tabs.forEach(t => {
      const info = OS.TYPE_INFO[t.doc.type] || { ico: "📄" };
      const el = document.createElement("button");
      el.className = "tab" + (t.id === activeId ? " active" : "");
      el.dataset.id = t.id;
      el.innerHTML = `<span class="tab-ico">${info.ico}</span><span class="tab-name">${OS.util.escapeHtml(t.doc.name)}</span>${t.dirty ? '<span class="dirty-dot"></span>' : ""}<span class="tab-close">✕</span>`;
      el.addEventListener("click", e => {
        if (e.target.classList.contains("tab-close")) { e.stopPropagation(); closeTab(t.id); }
        else activate(t);
      });
      bar.appendChild(el);
    });
  }
  function renderTab(t) { renderTabbar(); updateTitle(); }

  function goHome() {
    if (activeId && activeTab() && activeTab().dirty) saveNow();
    $("#editor").hidden = true; $("#dashboard").hidden = false;
    $("#ribbon-host").hidden = true; $("#ribbon-host").innerHTML = "";
    $("#statusbar").hidden = true;
    _toWorkbenchNav(); // 返回工作台：面板隐藏、导航高亮复位
    $("#doc-title").textContent = "";
    closeBackstage();
    document.title = "绿角犀 Office · 跨平台办公套件";
    renderDashboard();
  }

  /* ---------------- 保存 ---------------- */
  async function persist(t) {
    if (!t) return;
    t.doc.data = t.instance.serialize();
    await OS.store.put(t.doc);
    t.dirty = false; renderTabbar(); updateTitle();
  }
  function markDirty() {
    const t = activeTab(); if (!t) return;
    t.dirty = true; renderTabbar(); updateTitle();
    if (OS.settings.get("autosave")) { clearTimeout(saveTimer); saveTimer = setTimeout(() => persist(t).catch(e => console.error("[Shell] 操作失败:", e)), 1200); }
    // 历史版本自动快照（debounce 2s + 30s 间隔节流，见 versions.js）
    if (OS.Versions && t.instance && typeof t.instance.serialize === "function") {
      OS.Versions.autoSnap(t.doc.id, () => {
        try { return t.instance.serialize(); } catch (e) { return null; }
      });
    }
  }
  async function saveNow() {
    const t = activeTab(); if (!t) return;
    if (!OS.Tasks) { try { await persist(t); OS.toast("已保存", "ok"); } catch (e) { OS.toast("保存失败：" + e.message, "err"); } return; }
    OS.Tasks.run("保存 " + t.doc.name, async r => {
      r.step("读取编辑内容");
      t.doc.data = t.instance.serialize();
      r.step("写入本地数据库");
      await OS.store.put(t.doc);
      r.step("完成");
      t.dirty = false; renderTabbar(); updateTitle();
    }, { doneMsg: "已保存" });
  }

  /* ---------------- 状态栏 ---------------- */
  function applyZoom(delta) {
    zoom = Math.max(50, Math.min(400, zoom + delta));
    const wrap = document.querySelector("#module-host .module-wrap");
    if (wrap) wrap.style.zoom = zoom / 100;
    const v = document.querySelector(".sb-zoomval"); if (v) v.textContent = zoom + "%";
  }
  function renderStatusbar() {
    const t = activeTab(); if (!t) return;
    const info = OS.TYPE_INFO[t.doc.type] || { name: t.doc.type };
    const comp = OS.COMPAT[t.doc.compat];
    const sb = $("#statusbar");
    const isSheet = t.doc.type === "spreadsheet";
    sb.hidden = isSheet;  // spreadsheet 模块隐藏全局 footer，用模块内 bottombar
    const html = `
      <span class="sb-item">${info.name}</span>
      <span class="sb-item">${OS.util.fmtSize(t.doc.size || 0)}</span>
      ${comp ? `<span class="sb-item" style="color:${comp.color.replace('var(--ok)','#0e7c3a').replace('var(--warn)','#b9700f').replace('var(--danger)','#c4312b')}">${comp.label}</span>` : ""}
      <span class="sb-item sb-spacer"></span>
      <span class="sb-item sb-tasks" id="sb-tasks" hidden>
        <button id="sb-tasks-btn" title="任务进程 (Alt+T)">${ICON().svg("tasks", 14)}<span>任务</span><b class="sb-tasks-count">0</b></button>
      </span>
      <span class="sb-item" id="sb-ready">就绪</span>
      <span class="sb-item sb-zoom">
        <button id="zb-out" title="缩小">−</button>
        <span class="sb-zoomval" id="zb-val" title="重置为 100%">${zoom}%</span>
        <button id="zb-in" title="放大">＋</button>
      </span>`;
    sb.innerHTML = html;
    // spreadsheet: 同步到模块内 bottombar
    if (isSheet) {
      const sf = document.querySelector(".sheet-footer");
      if (sf) { sf.innerHTML = html; sf.hidden = false; }
    }
    const zbOut = document.querySelector("#zb-out") || document.querySelector(".sheet-footer #zb-out");
    const zbIn = document.querySelector("#zb-in") || document.querySelector(".sheet-footer #zb-in");
    const zbVal = document.querySelector("#zb-val") || document.querySelector(".sheet-footer #zb-val");
    if (zbOut) zbOut.onclick = () => applyZoom(-10);
    if (zbIn) zbIn.onclick = () => applyZoom(10);
    if (zbVal) zbVal.onclick = () => { zoom = 100; applyZoom(0); };
    const tasksBtn = document.querySelector("#sb-tasks-btn") || document.querySelector(".sheet-footer #sb-tasks-btn");
    if (tasksBtn) {
      tasksBtn.onclick = () => OS.Tasks && OS.Tasks.togglePanel();
      OS.Tasks && OS.Tasks.setBadgeEl(document.querySelector("#sb-tasks") || document.querySelector(".sheet-footer #sb-tasks"));
    }
  }

  /* ---------------- 导入 ---------------- */
  // TODO: [坑-electron-contextisolation-下-global-window] 预防：导入 OOXML/ODF 前确保第三方库已挂载（见 issues.md 对应条目）
  async function importFileObj(f) {
    const ext = (f.name.split(".").pop() || "").toLowerCase();
    const SUPPORTED = ["docx", "xlsx", "xls", "pptx", "odt", "ods", "odp", "ofd", "xmind", "opml", "pdf", "html", "txt", "md", "csv", "json"];
    if (!ext || !SUPPORTED.includes(ext)) {
      OS.toast(`暂不支持 .${ext || "(无扩展名)"} 格式，支持：${SUPPORTED.slice(0, 6).join("/")} 等`, "err"); return;
    }
    if (!OS.Tasks) return OS.toast(`正在导入 ${f.name} …`);
    console.time("[IMPORT]"); OS.Tasks.run("导入 " + f.name, async (r) => {
      try {
        r.step("读取文件");
        if (ext === "pdf") {
          const url = await _phase("import.pdf.readFile", OS.util.readFile(f, true), 10000);
          const doc = await _phase("import.pdf.create", OS.store.create({ type: "pdf", name: f.name }), 10000);
          doc.data = { name: f.name, dataUrl: url };
          await _phase("import.pdf.put", OS.store.put(doc), 10000);
          await _phase("import.pdf.openDoc", openDoc(doc), 15000);
          return;
        }
        if (ext === "html") {
          const html = await _phase("import.html.readFile", OS.util.readFile(f, false), 10000);
          const doc = await OS.store.create({ type: "writer", name: f.name.replace(/\.html?$/i, "") });
          doc.data = { html: htmlBody(html) }; await OS.store.put(doc);
          await _phase("import.html.openDoc", openDoc(doc), 15000); return;
        }
        if (ext === "txt") {
          const txt = await _phase("import.txt.readFile", OS.util.readFile(f, false), 10000);
          const html = txt.split(/\n{2,}/).map(p => `<p>${OS.util.escapeHtml(p).replace(/\n/g, "<br>")}</p>`).join("");
          const doc = await OS.store.create({ type: "writer", name: f.name });
          doc.data = { html: `<h1>${OS.util.escapeHtml(f.name)}</h1>` + html }; await OS.store.put(doc);
          await _phase("import.txt.openDoc", openDoc(doc), 15000); return;
        }
        if (ext === "md") {
          const mdTxt = await _phase("import.md.readFile", OS.util.readFile(f, false), 10000);
          const doc = await OS.store.create({ type: "markdown", name: f.name });
          doc.data = { mode: "split", source: mdTxt, html: "" }; await OS.store.put(doc);
          await _phase("import.md.openDoc", openDoc(doc), 15000); return;
        }
        if (ext === "csv") {
          const txt = await _phase("import.csv.readFile", OS.util.readFile(f, false), 10000);
          const doc = await OS.store.create({ type: "spreadsheet", name: f.name });
          doc.data = csvToSheet(txt); await OS.store.put(doc);
          await _phase("import.csv.openDoc", openDoc(doc), 15000); return;
        }
        if (["docx", "xlsx", "xls", "pptx", "odt", "ods", "odp", "ofd", "xmind"].includes(ext)) {
          const r2 = await _phase("import." + ext + ".parse",
            OS.Importer.importFile(f, (s, p) => { r.step(s, p); console.log('[PHASE-STEP]', s, p); }),
            30000); // 解析 OOXML/ODF/XMind 可以慢一点，30s 上限
          if (r2) {
            r.step("保存到本地", 0.95);
            const doc = await _phase("import." + ext + ".create",
              OS.store.create({ type: r2.type, name: f.name.replace(/\.[^.]+$/i, "") }), 10000);
            doc.data = r2.data; doc.compat = r2.compat || "B";
            await _phase("import." + ext + ".put", OS.store.put(doc), 10000);
            r.step("渲染中...");
            await _phase("import." + ext + ".openDoc", openDoc(doc), 15000);
            console.timeEnd("[IMPORT]");
            if (r2.note) OS.toast(r2.note, "ok");
            return;
          }
          throw new Error(`解析失败，${ext} 返回空结果`);
        }
        throw new Error("暂不支持该格式：" + ext);
      } catch(e) {
        console.error("[IMPORT] FATAL:", e.message, '\n' + e.stack);
        console.error('[DIAG] 卡在哪？请在 F12 控制台执行 __diagnose() 查看 phase 状态');
        OS.toast("导入失败：" + e.message, "err");
        throw e; // re-throw 让 Tasks.run 标记 error
      }
    }, { doneMsg: "导入完成", errorMsg: "导入失败" });
  }
  function onFile(e) {
    const f = e.target.files[0]; if (!f) return; e.target.value = "";
    importFileObj(f).catch(e => { console.error("[Shell] importFileObj(onFile) 异常:", e); OS.toast("导入失败：" + (e && e.message || e), "err"); });
  }
  // 文件关联（双击/默认打开方式）推来的 base64 还原为可打开对象
  function b64ToBlob(b64, mime) {
    const bin = atob(b64);
    const len = bin.length;
    const arr = new Uint8Array(len);
    for (let i = 0; i < len; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime || "application/octet-stream" });
  }
  function mimeFor(ext) {
    const m = {
      pdf: "application/pdf", ofd: "application/ofd",
      docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      xls:  "application/vnd.ms-excel",
      pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
      csv: "text/csv", txt: "text/plain", md: "text/markdown", html: "text/html", htm: "text/html",
      xmind: "application/vnd.xmind.workbook", lvjx: "application/octet-stream"
    };
    return m[(ext || "").toLowerCase().replace(/^\./, "")] || "application/octet-stream";
  }
  function htmlBody(html) {
    const m = /<body[^>]*>([\s\S]*)<\/body>/i.exec(html);
    return m ? m[1] : html;
  }
  function csvToSheet(txt) {
    const rows = txt.split(/\r?\n/).filter(r => r.length);
    const cells = {};
    rows.forEach((r, i) => {
      r.split(",").forEach((c, j) => { const v = c.trim().replace(/^"|"$/g, ""); if (v) cells[OS.FormulaEngine.idxToCol(j + 1) + (i + 1)] = { v: isNaN(+v) && v !== "" ? v : +v }; });
    });
    return { rows: Math.max(rows.length, 50), cols: 16, cells, styles: {} };
  }

  /* ---------------- 导出菜单 ---------------- */
  function showExportMenu() {
    const t = activeTab(); if (!t) { OS.toast("没有打开的文档", "warn"); return; }
    const fmts = {
      writer: [["html", "HTML 网页"], ["docx", "DOCX (Word) · 原生"], ["pdf", "PDF（打印）"], ["txt", "纯文本"]],
      spreadsheet: [["csv", "CSV"], ["xlsx", "XLSX (Excel) · 原生"], ["html", "HTML"], ["pdf", "PDF（打印）"], ["pdffile", "PDF 文件（直接下载）"], ["json", "JSON"]],
      presentation: [["pptx", "PPTX (PowerPoint) · 原生"], ["html", "HTML 讲稿（备注）"], ["docx", "DOCX 讲稿（备注）"], ["ofd", "OFD 版式 (国标)"], ["json", "JSON"], ["pdf", "PDF（打印）"], ["pdffile", "PDF 文件（直接下载）"], ["png", "PNG 图片"]],
      mindmap: [["svg", "SVG 矢量图"], ["png", "PNG 图片"], ["json", "JSON 数据"]],
      pdf: [["pdf", "原始 PDF"], ["json", "JSON 元数据"]]
    }[t.doc.type] || [["json", "JSON"]];
    const NATIVE = ["docx", "xlsx", "pptx", "ofd"];
    const ov = document.createElement("div");
    ov.className = "overlay"; ov.id = "export-overlay";
    ov.innerHTML = `<div class="drawer"><div class="drawer-head"><h3>导出 · ${OS.util.escapeHtml(t.doc.name)}</h3><button class="icon-btn" data-x>✕</button></div>
      <div class="drawer-body">${fmts.map(([f, l]) => `<button class="btn" data-fmt="${f}" style="display:block;width:100%;margin-bottom:8px;justify-content:flex-start">${l}</button>`).join("")}</div></div>`;
    document.body.appendChild(ov);
    ov.addEventListener("click", e => {
      if (e.target === ov || e.target.dataset.x) { ov.remove(); return; }
      const b = e.target.closest("[data-fmt]");
      if (b) {
        const f = b.dataset.fmt;
        const label = (fmts.find(x => x[0] === f) || [f, f])[1];
        runExport(t, f, label, NATIVE.includes(f));
        ov.remove();
      }
    });
  }

  /* 统一导出任务（原生格式走 OS.Exporter，其余走模块 exportAs） */
  function runExport(tab, f, label, native) {
    if (!OS.Tasks) {
      if (native && OS.Exporter) OS.Exporter.exportDoc(tab.doc, f).catch(err => OS.toast("导出失败：" + err.message, "err"));
      else if (tab.instance.exportAs) tab.instance.exportAs(f);
      return;
    }
    OS.Tasks.run("导出 " + label, async r => {
      r.step("准备 " + f.toUpperCase());
      if (native && OS.Exporter) {
        await OS.Exporter.exportDoc(tab.doc, f, (s, p) => r.step(s, p));
      } else if (tab.instance.exportAs) {
        tab.instance.exportAs(f);
      } else {
        throw new Error("当前模块不支持导出：" + f);
      }
      r.step("完成");
    }, { doneMsg: null });
  }

  /* ---------------- 文件后台 (Backstage) ---------------- */
  function openBackstage() {
    const t = activeTab(); if (!t) return;
    const root = $("#backstage-root");
    const doc = t.doc;
    const info = OS.TYPE_INFO[doc.type] || { name: doc.type, ext: "" };
    const comp = OS.COMPAT[doc.compat];
    root.innerHTML = `
      <div class="backstage">
        <nav class="backstage-nav">
          <div class="bs-brand"><span class="dot"></span>文件</div>
          <div class="bs-label">操作</div>
          <button data-bs="info" class="active">${ICON().svg("info", 18)}<span>信息</span></button>
          <button data-bs="save">${ICON().svg("save", 18)}<span>保存</span></button>
          <button data-bs="history">${ICON().svg("undo", 18)}<span>历史版本</span></button>
          <button data-bs="template">${ICON().svg("star", 18)}<span>我的模板</span></button>
          <button data-bs="export">${ICON().svg("export", 18)}<span>导出</span></button>
          <button data-bs="print">${ICON().svg("print", 18)}<span>打印</span></button>
          <div class="bs-label">文档</div>
          <button data-bs="close">${ICON().svg("close", 18)}<span>关闭</span></button>
        </nav>
        <div class="backstage-content" id="bs-content">
          <button class="bs-close" id="bs-close" title="返回 (Esc)">✕</button>
          ${bsInfoHTML(doc, info, comp)}
        </div>
      </div>`;
    const bs = root.querySelector(".backstage");
    const content = root.querySelector("#bs-content");
    root.querySelector("#bs-close").onclick = closeBackstage;

    // 渲染「我的模板」管理列表（含删除）
    function renderCustomList(ul) {
      const items = OS.CustomTemplates ? OS.CustomTemplates.all() : [];
      ul.innerHTML = "";
      if (!items.length) {
        ul.innerHTML = '<p class="muted">还没有自定义模板。编辑文档后点「保存为模板」即可创建，它会出现在开始页的「自定义」分组。</p>';
        return;
      }
      items.forEach(it => {
        const row = document.createElement("div");
        row.className = "bs-tpl-item";
        const typeName = (OS.TYPE_INFO[it.module] || { name: it.module }).name;
        row.innerHTML =
          `<span class="bs-tpl-name">${OS.util.escapeHtml(it.name)}</span>` +
          `<span class="bs-tpl-mod">${OS.util.escapeHtml(typeName)}</span>` +
          `<button class="bs-tpl-del" title="删除模板" aria-label="删除模板">🗑</button>`;
        row.querySelector(".bs-tpl-del").addEventListener("click", () => {
          if (confirm(`删除模板「${it.name}」？此操作不可撤销。`)) {
            OS.CustomTemplates.remove(it.id);
            renderCustomList(ul);
            renderDashboard();
            OS.toast("已删除模板", "ok");
          }
        });
        ul.appendChild(row);
      });
    }

    bs.querySelector(".backstage-nav").addEventListener("click", e => {
      const b = e.target.closest("[data-bs]"); if (!b) return;
      bs.querySelectorAll(".backstage-nav button").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      const k = b.dataset.bs;
      if (k === "info") content.innerHTML = `<button class="bs-close" id="bs-close">✕</button>` + bsInfoHTML(doc, info, comp), content.querySelector("#bs-close").onclick = closeBackstage;
      else if (k === "save") { saveNow(); content.innerHTML = `<button class="bs-close" id="bs-close">✕</button><h2>保存</h2><p class="bs-sub">文档已保存到本机存储。</p><div class="bs-actions"><button class="btn primary" id="bs-done">完成</button></div>`; content.querySelector("#bs-close").onclick = closeBackstage; content.querySelector("#bs-done").onclick = closeBackstage; }
      else if (k === "history") {
        content.innerHTML = `<button class="bs-close" id="bs-close">✕</button>` +
          `<h2>${ICON().svg("undo", 18)} 历史版本</h2>` +
          `<p class="bs-sub">文档的快照历史（每 30 秒自动存一次，编辑触发）。最多保留 50 个版本，超出自动清理最旧的。</p>` +
          `<div class="bs-hist-actions">` +
            `<button class="btn primary" id="bs-hist-snap" title="立即存一个快照">${ICON().svg("save", 16)} 立即快照</button>` +
            `<button class="btn" id="bs-hist-refresh" title="刷新列表">${ICON().svg("undo", 16)} 刷新</button>` +
          `</div>` +
          `<div class="bs-hist-toolbar"><span class="muted" id="bs-hist-count">加载中…</span></div>` +
          `<div class="bs-hist-list" id="bs-hist-list"></div>` +
          `<div class="bs-hist-diff" id="bs-hist-diff" hidden></div>`;
        content.querySelector("#bs-close").onclick = closeBackstage;
        const listEl = content.querySelector("#bs-hist-list");
        const countEl = content.querySelector("#bs-hist-count");
        const diffEl = content.querySelector("#bs-hist-diff");
        let selectedForDiff = []; // [idA, idB]
        async function refreshHistList() {
          if (!OS.Versions) { listEl.innerHTML = '<p class="muted">历史版本模块未就绪，请重启应用。</p>'; return; }
          const list = await OS.Versions.list(doc.id);
          countEl.textContent = list.length ? (list.length + " 个版本") : "尚无快照";
          if (!list.length) { listEl.innerHTML = '<p class="muted">还没有快照。点「立即快照」存一个，或编辑文档后等 30 秒自动存。</p>'; return; }
          listEl.innerHTML = "";
          list.forEach((v, idx) => {
            const row = document.createElement("div");
            row.className = "bs-hist-row";
            row.dataset.id = v.id;
            const reasonText = v.reason === "auto-save" ? "自动" : (v.reason === "pre-revert" ? "回退前" : (v.reason === "manual" ? "手动" : v.reason));
            const isLatest = idx === 0;
            row.innerHTML =
              `<div class="bs-hist-main">` +
                `<div class="bs-hist-time">${OS.util.escapeHtml(new Date(v.ts).toLocaleString())}${isLatest ? ' <span class="bs-hist-tag">最新</span>' : ""}</div>` +
                `<div class="bs-hist-meta">${OS.util.escapeHtml(v.label || "")} · ${reasonText} · ${OS.util.fmtSize(v.size || 0)}</div>` +
              `</div>` +
              `<div class="bs-hist-acts">` +
                `<button class="btn bs-hist-diff-pick" title="选中后点其他版本对比">${selectedForDiff.includes(v.id) ? "✓ 已选" : "对比"}</button>` +
                `<button class="btn bs-hist-revert" title="回退到该版本（自动存回退前备份）">回退</button>` +
                `<button class="btn bs-hist-del" title="删除该版本">删除</button>` +
              `</div>`;
            row.querySelector(".bs-hist-diff-pick").onclick = () => {
              const i = selectedForDiff.indexOf(v.id);
              if (i >= 0) selectedForDiff.splice(i, 1);
              else { selectedForDiff.push(v.id); if (selectedForDiff.length > 2) selectedForDiff.shift(); }
              if (selectedForDiff.length === 2) { renderDiff(selectedForDiff[0], selectedForDiff[1]); }
              else { diffEl.hidden = true; diffEl.innerHTML = ""; }
              refreshHistList();
            };
            row.querySelector(".bs-hist-revert").onclick = async () => {
              if (!confirm(`回退到 ${new Date(v.ts).toLocaleString()} 的版本？\n\n系统会先存当前状态为「回退前备份」，让你随时还能撤销这次回退。`)) return;
              try {
                const state = await OS.Versions.revert(doc.id, v.id);
                if (!state) { OS.toast("回退失败：版本数据为空", "err"); return; }
                t.doc.data = state;
                await OS.store.put(t.doc);
                closeBackstage();
                // 通过 closeTab + openDoc 重新挂载模块以应用新状态
                const id = t.id;
                const idx2 = tabs.findIndex(x => x.id === id);
                if (idx2 >= 0) {
                  if (tabs[idx2].instance.destroy) try { tabs[idx2].instance.destroy(); } catch (e) { console.warn("[Shell] destroy 失败:", e); }
                  OS.Undo.unbindModule(id);
                  tabs.splice(idx2, 1);
                }
                await openDoc(t.doc);
                OS.toast("已回退，回退前状态已自动存档", "ok");
              } catch (e) { OS.toast("回退失败：" + e.message, "err"); }
            };
            row.querySelector(".bs-hist-del").onclick = async () => {
              if (!confirm("删除该版本？此操作不可撤销。")) return;
              await OS.Versions.remove(v.id);
              refreshHistList();
              OS.toast("已删除版本", "ok");
            };
            listEl.appendChild(row);
          });
        }
        async function renderDiff(idA, idB) {
          const d = await OS.Versions.diff(idA, idB);
          if (!d) { diffEl.innerHTML = '<p class="muted">对比失败：找不到版本</p>'; diffEl.hidden = false; return; }
          const lines = [];
          d.removed.forEach(l => lines.push(`<div class="bs-diff-line bs-diff-del">- ${OS.util.escapeHtml(l.text)}</div>`));
          d.added.forEach(l => lines.push(`<div class="bs-diff-line bs-diff-add">+ ${OS.util.escapeHtml(l.text)}</div>`));
          diffEl.innerHTML =
            `<div class="bs-diff-head">` +
              `<span>对比：${OS.util.escapeHtml(d.a.date)} ↔ ${OS.util.escapeHtml(d.b.date)}</span>` +
              `<span class="muted">+${d.summary.addedCount} / -${d.summary.removedCount} / =${d.summary.unchangedCount}</span>` +
            `</div>` +
            `<div class="bs-diff-body">${lines.join("") || '<p class="muted">两版完全相同</p>'}</div>`;
          diffEl.hidden = false;
        }
        content.querySelector("#bs-hist-snap").onclick = async () => {
          if (!OS.Versions || !t.instance || !t.instance.serialize) { OS.toast("无序列化方法", "err"); return; }
          try {
            const state = t.instance.serialize();
            await OS.Versions.save(doc.id, state, { reason: "manual", label: "手动快照" });
            OS.toast("已存快照", "ok");
            refreshHistList();
          } catch (e) { OS.toast("快照失败：" + e.message, "err"); }
        };
        content.querySelector("#bs-hist-refresh").onclick = refreshHistList;
        refreshHistList();
      }
      else if (k === "template") {
        content.innerHTML = `<button class="bs-close" id="bs-close">✕</button>` +
          `<h2>我的模板</h2>` +
          `<p class="bs-sub">将当前文档保存为可复用的个人模板，出现在开始页「自定义」分组。</p>` +
          `<div class="bs-tpl-form">` +
            `<input id="bs-tpl-name" class="bs-input" placeholder="模板名称" value="${OS.util.escapeHtml(doc.name)}">` +
            `<button class="btn primary" id="bs-tpl-save">${ICON().svg("plus", 16)} 保存为模板</button>` +
          `</div>` +
          `<div class="bs-tpl-actions">` +
            `<button class="btn" id="bs-tpl-export">${ICON().svg("download", 16)} 导出模板包</button>` +
            `<button class="btn" id="bs-tpl-import">${ICON().svg("upload", 16)} 导入模板包</button>` +
            `<input type="file" id="bs-tpl-file" accept="application/json,.json" hidden>` +
          `</div>` +
          `<div class="bs-tpl-list" id="bs-tpl-list"></div>`;
        content.querySelector("#bs-close").onclick = closeBackstage;
        const listEl = content.querySelector("#bs-tpl-list");
        renderCustomList(listEl);
        content.querySelector("#bs-tpl-save").addEventListener("click", () => {
          const name = content.querySelector("#bs-tpl-name").value.trim() || doc.name;
          const data = t.instance.serialize();
          OS.CustomTemplates.add({ name, module: doc.type, data });
          renderCustomList(listEl);
          renderDashboard();
          OS.toast("已保存为模板：" + name, "ok");
        });
        content.querySelector("#bs-tpl-export").addEventListener("click", () => {
          const json = OS.CustomTemplates.exportAll();
          OS.util.download(new Blob([json], { type: "application/json" }), "绿角犀模板包.json");
          OS.toast("已导出模板包", "ok");
        });
        const fileInput = content.querySelector("#bs-tpl-file");
        content.querySelector("#bs-tpl-import").addEventListener("click", () => fileInput.click());
        fileInput.addEventListener("change", async (e) => {
          const f = e.target.files && e.target.files[0];
          if (!f) return;
          try {
            const text = await f.text();
            const r = OS.CustomTemplates.importFrom(text);
            renderCustomList(listEl);
            renderDashboard();
            if (r.errors) OS.toast(`导入完成：新增 ${r.added}，跳过 ${r.skipped}，失败 ${r.errors}`, "warn");
            else OS.toast(`已导入模板包：新增 ${r.added}，跳过 ${r.skipped}`, "ok");
          } catch (err) { OS.toast("导入失败：" + ((err && err.message) || err), "error"); }
          fileInput.value = "";
        });
      }
      else if (k === "export") { closeBackstage(); showExportMenu(); }
      else if (k === "print") { closeBackstage(); if (t.instance.exportAs) t.instance.exportAs("pdf"); else window.print(); }
      else if (k === "close") { closeBackstage(); closeTab(doc.id); }
    });
  }
  function bsInfoHTML(doc, info, comp) {
    return `<h2>信息</h2><p class="bs-sub">${info.name} · ${OS.util.escapeHtml(doc.name)}</p>
      <div class="bs-info-grid">
        <div class="bs-info-card"><h4>类型</h4><div class="val">${info.name}（.${info.ext}）</div></div>
        <div class="bs-info-card"><h4>大小</h4><div class="val">${OS.util.fmtSize(doc.size || 0)}</div></div>
        <div class="bs-info-card"><h4>兼容等级</h4><div class="val" style="color:${comp ? comp.color.replace('var(--ok)','#0e7c3a').replace('var(--warn)','#b9700f').replace('var(--danger)','#c4312b') : 'inherit'}">${comp ? comp.label : "未知"}</div></div>
        <div class="bs-info-card"><h4>修改时间</h4><div class="val">${OS.util.fmtTime(doc.updatedAt)}</div></div>
      </div>
      <p class="muted">${comp ? comp.desc : ""}</p>
      <div class="bs-actions">
        <button class="btn primary" id="bs-save2">${ICON().svg("save", 16)} 保存</button>
        <button class="btn" id="bs-exp2">${ICON().svg("export", 16)} 导出</button>
      </div>`;
  }
  function closeBackstage() { const r = $("#backstage-root"); if (r) r.innerHTML = ""; }

  /* ---------------- 命令面板 ---------------- */
  // 模糊搜索：子序列匹配（支持跳过字符）+ 中文前缀 + 英文前缀 + 权重
  function _fuzzyScore(label, q) {
    if (!q) return 100;
    const lo = label.toLowerCase(), qo = q.toLowerCase();
    if (lo.includes(qo)) return 100 - lo.indexOf(qo) * 2; // includes 优先
    // 子序列：q 的每个字符必须按序出现在 label 里
    let li = 0, qi = 0, gap = 0;
    while (li < lo.length && qi < qo.length) {
      if (lo[li] === qo[qi]) { qi++; } else { gap++; }
      li++;
    }
    if (qi < qo.length) return -1; // 没匹配完
    return 50 - gap * 2; // gap 越小分数越高
  }
  const COMMANDS = [
    // —— 新建 / 打开 ——
    { id: "new-writer", label: "新建 Writer 文档", hint: "Ctrl/Cmd+N", run: () => newDoc("writer"), group: "新建" },
    { id: "new-sheet", label: "新建 Spreadsheet 表格", hint: "", run: () => newDoc("spreadsheet"), group: "新建" },
    { id: "new-pres", label: "新建 Presentation 演示", hint: "", run: () => newDoc("presentation"), group: "新建" },
    { id: "new-mindmap", label: "新建 MindMap 脑图", hint: "", run: () => newDoc("mindmap"), group: "新建" },
    { id: "new-pdf", label: "新建 PDF 视图", hint: "", run: () => newDoc("pdf"), group: "新建" },
    { id: "open", label: "打开文件", hint: "Ctrl/Cmd+O", run: () => $("#file-input").click(), group: "文件" },
    { id: "save", label: "保存当前文档", hint: "Ctrl/Cmd+S", run: saveNow, group: "文件" },
    { id: "export", label: "导出当前文档", hint: "Ctrl/Cmd+E", run: showExportMenu, group: "文件" },
    { id: "close-tab", label: "关闭当前标签", hint: "Ctrl/Cmd+W", run: () => { const t = activeTab(); if (t) closeTab(t.id); else closeBackstage && closeBackstage(); }, group: "文件" },
    { id: "reopen-tab", label: "重开最近关闭标签", hint: "Ctrl/Cmd+Shift+T", run: reopenRecentlyClosed, group: "文件" },
    { id: "quit", label: "退出应用", hint: "Ctrl/Cmd+Q", run: () => { if (global.electronAPI && global.electronAPI.invoke) global.electronAPI.invoke("app:quit"); else window.close(); }, group: "文件" },
    // —— 导航 ——
    { id: "home", label: "返回首页", hint: "Ctrl/Cmd+Shift+H", run: goHome, group: "导航" },
    { id: "search", label: "全局搜索文档", hint: "Ctrl/Cmd+Shift+F", run: openSearch, group: "导航" },
    { id: "prev-tab", label: "上一个标签", hint: "Ctrl+Shift+Tab", run: () => { if (tabs.length >= 2) { const curIdx = tabs.findIndex(t => t.id === activeId); activate(tabs[(curIdx - 1 + tabs.length) % tabs.length]); } }, group: "导航" },
    { id: "next-tab", label: "下一个标签", hint: "Ctrl+Tab", run: () => { if (tabs.length >= 2) { const curIdx = tabs.findIndex(t => t.id === activeId); activate(tabs[(curIdx + 1) % tabs.length]); } }, group: "导航" },
    { id: "jump-tab", label: "跳转到第 N 个标签", hint: "输数字 1-99", run: () => {}, group: "导航", dynamic: true },
    { id: "about", label: "关于 / 帮助", hint: "F1", run: showAbout, group: "帮助" },
    { id: "check-update", label: "检查更新", hint: "", run: () => { if (OS.updater) OS.updater.checkNow({ toast: true }); }, group: "帮助" },
    // —— 编辑 ——
    { id: "replace", label: "查找替换", hint: "Ctrl/Cmd+H", run: openReplace, group: "编辑" },
    // —— 视图 ——
    { id: "theme", label: "切换深色/浅色主题", hint: "", run: () => OS.theme.toggle(), group: "视图" },
    { id: "refresh", label: "刷新窗口", hint: "F5 / Ctrl+R", run: () => { if (global.electronAPI && global.electronAPI.invoke) global.electronAPI.invoke("app:reload"); else location.reload(); }, group: "视图" },
    // —— AI / 工具 ——
    { id: "ai", label: "打开 AI 助手", hint: "Ctrl/Cmd+Shift+A", run: openAI, group: "工具" },
    { id: "tasks", label: "任务面板", hint: "Alt+T", run: () => OS.Tasks && OS.Tasks.togglePanel(), group: "工具" },
    { id: "shortcuts", label: "快捷键速查表", hint: "", run: showShortcuts, group: "帮助" },
  ];
  // F1 — 帮助 / 关于弹窗
  function showAbout() {
    const v = (global.APP_VERSION) || "dev";
    const hasInstall = typeof window.__installPrompt === "function" && window.__installPrompt();
    const installBtn = hasInstall
      ? `<button class="btn" onclick="(async function(){const p=window.__installPrompt&&window.__installPrompt();if(p){await p.prompt();const r=await p.userChoice;if(r.outcome==='accepted'){document.getElementById('about-overlay').remove();OS.toast&&OS.toast('✅ 已安装到桌面');}}else{OS.toast&&OS.toast('当前环境不支持安装');}})()">📱 安装</button>`
      : "";
    const html = `<div class="overlay show" id="about-overlay" style="z-index:9999"><div class="modal" style="min-width:360px;text-align:center;padding:24px"><h2 style="margin:0 0 4px">绿角犀 Office</h2><p class="muted" style="margin:0 0 16px">v${v} · 本地优先的办公套件</p><p style="font-size:13px;color:#6b7280;margin:0 0 16px">Writer · Spreadsheet · Presentation · PDF · MindMap</p><div style="display:flex;gap:8px;justify-content:center;margin-top:8px">${installBtn}<button class="btn" onclick="(function(){document.getElementById('about-overlay').remove();showShortcuts()})()">⌨️ 快捷键</button><button class="btn" onclick="(function(){document.getElementById('about-overlay').remove();if(window.OS&&OS.updater){OS.updater.checkNow({toast:true})}})()">🔄 检查更新</button><button class="btn primary" onclick="document.getElementById('about-overlay').remove()">知道了</button></div></div></div>`;
    const old = document.getElementById("about-overlay"); if (old) old.remove();
    document.body.insertAdjacentHTML("beforeend", html);
  }
  function showShortcuts() {
    const groups = [
      { title: "文件", rows: [
        ["Ctrl/Cmd+N", "新建 Writer 文档"], ["Ctrl/Cmd+O", "打开文件"],
        ["Ctrl/Cmd+S", "保存当前文档"], ["Ctrl/Cmd+E", "导出"],
        ["Ctrl/Cmd+W", "关闭当前标签"], ["Ctrl/Cmd+Shift+T", "重开最近关闭"],
        ["Ctrl/Cmd+Q", "退出应用"],
      ]},
      { title: "标签 / 导航", rows: [
        ["Ctrl+Tab", "下一个标签（可视化弹窗）"], ["Ctrl+Shift+Tab", "上一个标签"],
        ["Ctrl/Cmd+Shift+H", "返回首页"], ["Ctrl/Cmd+Shift+F", "全局搜索"],
      ]},
      { title: "编辑", rows: [
        ["Ctrl/Cmd+Z", "撤销"], ["Ctrl/Cmd+Y / Ctrl+Shift+Z", "重做"],
        ["Ctrl/Cmd+F", "模块内查找"], ["Ctrl/Cmd+H", "查找替换"],
      ]},
      { title: "视图", rows: [
        ["F5 / Ctrl/Cmd+R", "刷新窗口"], ["Ctrl+K", "命令面板"],
        ["Esc", "关闭所有覆盖层"],
      ]},
      { title: "AI / 工具", rows: [
        ["Ctrl/Cmd+Shift+A", "打开 AI 助手"], ["Alt+T", "任务面板"],
        ["Ctrl/Cmd+Shift+M", "插入批注（Spreadsheet）"],
      ]},
      { title: "帮助", rows: [["F1", "关于 / 快捷键"]] },
    ];
    let rowsHtml = groups.map(g => {
      const rows = g.rows.map(([k, v]) =>
        `<tr><td style="padding:6px 8px;border-bottom:1px solid var(--border,#e5e7eb);font-family:monospace;font-size:12px;color:var(--accent,#2563eb);white-space:nowrap">${k}</td><td style="padding:6px 8px;border-bottom:1px solid var(--border,#e5e7eb);font-size:13px;color:var(--text,#111827)">${v}</td></tr>`
      ).join("");
      return `<div style="margin:12px 0 4px;font-size:11px;color:var(--muted,#6b7280);text-transform:uppercase;letter-spacing:0.5px;font-weight:600">${g.title}</div><table style="width:100%;border-collapse:collapse">${rows}</table>`;
    }).join("");
    const html = `<div class="overlay show" id="shortcuts-overlay" style="z-index:9999"><div class="modal" style="min-width:520px;max-width:640px;max-height:80vh;overflow-y:auto;padding:20px 24px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h2 style="margin:0">⌨️ 快捷键速查表</h2><button class="btn" onclick="document.getElementById('shortcuts-overlay').remove()">关闭</button></div><p class="muted" style="margin:0 0 12px;font-size:12px">${groups.reduce((s,g)=>s+g.rows.length,0)} 组快捷键 · 按 Ctrl+K 输入"快捷键"可随时调出</p>${rowsHtml}</div></div>`;
    const old = document.getElementById("shortcuts-overlay"); if (old) old.remove();
    document.body.insertAdjacentHTML("beforeend", html);
  }
  function openCmd() {
    const ov = $("#cmd-overlay"); ov.hidden = false;
    const input = $("#cmd-input"); input.value = ""; input.focus();
    renderCmd("");
    input.oninput = () => renderCmd(input.value);
    ov.onclick = e => { if (e.target === ov) closeOverlays(); };
  }
  let _cmdHighlight = 0;
  let _cmdListEl = null;
  let _cmdGroupEl = null;
  function renderCmd(q) {
    const list = $("#cmd-list"); list.innerHTML = "";
    const ql = q.trim();
    // 动态项：纯数字 → 跳转到第 N 个标签
    const numMatch = ql.match(/^(\d{1,2})$/);
    if (numMatch) {
      const n = parseInt(numMatch[1], 10);
      if (tabs.length && n >= 1 && n <= tabs.length) {
        const target = tabs[n - 1];
        list.innerHTML = `<li class="active" style="cursor:pointer;padding:8px 12px;background:var(--accent,#2563eb);color:#fff"><span>快速跳转：打开第 ${n} 个标签 → ${target.doc ? (target.doc.title || target.doc.type || "") : "工作台"}</span><span class="cmd-hint" style="color:rgba(255,255,255,0.7)">Enter</span></li>`;
        _cmdListEl = list; _cmdHighlight = 0;
        list.querySelector("li").onclick = () => { activate(target); closeOverlays(); };
        // 改 keydown handler（覆盖 renderCmd 里默认的）
        input.onkeydown = e => {
          if (e.key === "Enter") { e.preventDefault(); activate(target); closeOverlays(); }
          else if (e.key === "Escape") { closeOverlays(); }
        };
        return;
      } else if (tabs.length && n > tabs.length) {
        list.innerHTML = `<li style="color:var(--muted);padding:12px;text-align:center">只有 ${tabs.length} 个标签</li>`;
        _cmdListEl = list; _cmdHighlight = -1; return;
      }
    }
    let scored = COMMANDS.map(c => ({ c, score: _fuzzyScore(c.label + " " + (c.hint || "") + " " + (c.group || ""), ql) }))
      .filter(x => x.score >= 0)
      .sort((a, b) => b.score - a.score);
    if (!scored.length) {
      list.innerHTML = `<li style="color:var(--muted);padding:12px;text-align:center">未找到匹配命令</li>`;
      _cmdListEl = list; _cmdHighlight = -1; return;
    }
    // 按 group 分组
    const groups = {};
    for (const { c } of scored) { const g = c.group || "其他"; (groups[g] = groups[g] || []).push(c); }
    const frag = document.createDocumentFragment();
    _cmdListEl = list;
    _cmdHighlight = 0;
    let idx = 0;
    for (const [group, cmds] of Object.entries(groups)) {
      const hd = document.createElement("div"); hd.className = "cmd-group"; hd.textContent = group;
      Object.assign(hd.style, { fontSize: "11px", color: "var(--muted,#6b7280)", padding: "4px 12px 2px", textTransform: "uppercase", letterSpacing: "0.5px" });
      frag.appendChild(hd);
      for (const c of cmds) {
        const li = document.createElement("li");
        li.innerHTML = `<span>${c.label}</span><span class="cmd-hint">${c.hint || ""}</span>`;
        if (idx === 0) li.className = "active";
        li.dataset.idx = idx;
        li.onclick = () => { c.run(); closeOverlays(); };
        frag.appendChild(li);
        idx++;
      }
    }
    list.appendChild(frag);
    // 上下键选 + Enter 执行 + Esc 关闭
    input.onkeydown = e => {
      const items = list.querySelectorAll("li[data-idx]");
      if (!items.length) return;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        items[_cmdHighlight].classList.remove("active");
        _cmdHighlight = (_cmdHighlight + 1) % items.length;
        items[_cmdHighlight].classList.add("active");
        items[_cmdHighlight].scrollIntoView({ block: "nearest" });
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        items[_cmdHighlight].classList.remove("active");
        _cmdHighlight = (_cmdHighlight - 1 + items.length) % items.length;
        items[_cmdHighlight].classList.add("active");
        items[_cmdHighlight].scrollIntoView({ block: "nearest" });
      } else if (e.key === "Enter") {
        e.preventDefault();
        const sel = items[_cmdHighlight];
        if (sel) sel.click();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeOverlays();
      }
    };
  }
  function closeOverlays() {
    $("#cmd-overlay").hidden = true;
    const ex = document.getElementById("export-overlay"); if (ex) ex.remove();
    $("#acct-overlay").hidden = true;
    $("#ai-drawer").hidden = true;
    closeSearch();
    closeBackstage();
    _tswClose(true); // 关 tab-switcher（不切换）
  }

  // ---- Tab Switcher（Ctrl+Tab 可视化弹窗） ----
  function _tswOpen() {
    const curIdx = tabs.findIndex(t => t.id === activeId);
    const ov = document.createElement("div");
    ov.className = "tab-switcher-overlay";
    ov.innerHTML = `
      <div class="tab-switcher-panel">
        <div class="tab-switcher-title">按住 Ctrl + Tab 切换标签（松开 Ctrl 确认）</div>
        <div class="tab-switcher-list">${tabs.map((t, i) => {
          const mod = t.doc && t.doc.data && t.doc.data.modules ? t.doc.data.modules[0] : (t.doc && t.doc.type ? t.doc.type : "doc");
          const labels = { writer: "Writer", spreadsheet: "Sheet", presentation: "Slide", pdf: "PDF", mindmap: "MindMap" };
          const name = (t.doc && t.doc.name) || (t.doc && t.doc.title) || (t.doc && t.doc.type) || "未命名";
          return `<div class="tab-switcher-item ${i === (curIdx + 1) % tabs.length ? "active" : ""}" data-idx="${i}">
            <div class="tab-switcher-icon">${OS.icons.svg(mod === "writer" ? "doc" : mod === "spreadsheet" ? "grid" : mod === "pdf" ? "file" : mod === "presentation" ? "slides" : "mindmap", 18)}</div>
            <div class="tab-switcher-info">
              <div class="tab-switcher-name">${name}${t.dirty ? " ●" : ""}</div>
              <div class="tab-switcher-type">${labels[mod] || mod}</div>
            </div>
          </div>`;
        }).join("")}</div>
      </div>`;
    ov.addEventListener("click", e => {
      const item = e.target.closest(".tab-switcher-item");
      if (item) { _tswCommit(Number(item.dataset.idx)); _tswClose(true); }
    });
    document.body.appendChild(ov);
    requestAnimationFrame(() => ov.classList.add("show"));
    _tabSwitcher = { overlay: ov, curIdx: (curIdx + 1) % tabs.length, originalIdx: curIdx };
    // Ctrl 松开 → 确认切换
    window.addEventListener("keyup", _tswKeyup);
  }
  function _tswMove(dir) {
    if (!_tabSwitcher) return;
    const list = _tabSwitcher.overlay.querySelector(".tab-switcher-list");
    const items = list.querySelectorAll(".tab-switcher-item");
    items.forEach(i => i.classList.remove("active"));
    _tabSwitcher.curIdx = (_tabSwitcher.curIdx + dir + tabs.length) % tabs.length;
    items[_tabSwitcher.curIdx].classList.add("active");
    // 确保可见
    const el = items[_tabSwitcher.curIdx];
    if (el) el.scrollIntoView({ block: "nearest" });
  }
  function _tswKeyup(e) {
    if (!_tabSwitcher) return;
    if (!e.ctrlKey && !e.metaKey) { // Ctrl 已经松开 → 确认切换
      _tswCommit(_tabSwitcher.curIdx);
      _tswClose(false);
    }
  }
  function _tswCommit(idx) {
    if (idx >= 0 && idx < tabs.length) activate(tabs[idx]);
  }
  function _tswClose(silent) {
    if (!_tabSwitcher) return;
    window.removeEventListener("keyup", _tswKeyup);
    const ov = _tabSwitcher.overlay;
    _tabSwitcher = null;
    if (!ov) return;
    ov.classList.remove("show");
    setTimeout(() => { if (ov.parentNode) ov.parentNode.removeChild(ov); }, 120);
  }

  /* ---------------- AI 助手（Copilot 风格） ---------------- */
  const AI_SYS = {
    summarize: "请用简洁的中文总结用户提供的内容，保留关键信息与逻辑顺序。",
    polish: "请将用户提供的中文文本润色得更书面、通顺、专业，不改变原意。",
    rewrite: "请在不改变原意的前提下，用另一种表达改写用户文本。",
    expand: "请基于用户提供的文本进行合理扩写与展开论述。",
    continue: "请基于用户提供的文本进行自然续写。",
    outline: "请基于主题生成结构清晰的中文大纲。",
    translate: "请处理用户文本的翻译任务（术语对照 / 译文）。",
    explain: "请解释用户选中的概念或内容。"
  };
  function aiContext() {
    const t = activeTab(); if (!t) return null;
    return {
      doc: t.doc, inst: t.instance,
      selText() { const s = window.getSelection ? window.getSelection().toString() : ""; return (s || "").trim(); },
      fullText() { return getFullText(t.doc); },
      replaceSelection(text) {
        const sel = window.getSelection();
        if (sel && sel.rangeCount && !sel.isCollapsed) {
          try { document.execCommand("insertText", false, text); markDirty(); return true; } catch (e) { console.error("[Shell] 操作失败:", e); }
        }
        return false;
      },
      insertText(text) {
        if (this.replaceSelection(text)) return true;
        try { document.execCommand("insertText", false, text); markDirty(); return true; } catch (e) { console.error("[Shell] 操作失败:", e); }
        if (navigator.clipboard) navigator.clipboard.writeText(text).catch(e => console.error("[Shell] 操作失败:", e));
        OS.toast("已复制到剪贴板，请粘贴到文档", "ok"); return false;
      }
    };
  }
  function getFullText(doc) {
    const d = doc.data || {};
    if (doc.type === "writer") return OS.AI.stripHtml(d.html || "");
    if (doc.type === "spreadsheet") {
      const c = d.cells || {};
      return Object.keys(c).sort().map(k => c[k].v != null ? c[k].v : "").filter(Boolean).join("\n");
    }
    if (doc.type === "presentation") {
      return (d.slides || []).map(s => (s.elements || []).map(e => e.text || "").join(" ")).join("\n");
    }
    if (doc.type === "mindmap") {
      return (d.nodes || []).map(n => n.text || "").join("\n");
    }
    if (doc.type === "pdf") return "";
    return "";
  }
  function refreshAIContext() {
    const ctx = aiContext();
    const el = $("#ai-ctx");
    if (!ctx) { el.textContent = "未打开文档（可做自由问答）"; el.classList.add("ai-ctx-empty"); return; }
    el.classList.remove("ai-ctx-empty");
    const sel = ctx.selText();
    const full = ctx.fullText();
    if (sel) el.textContent = "📄 " + ctx.doc.name + " · 已选中 " + sel.length + " 字";
    else if (full) el.textContent = "📄 " + ctx.doc.name + " · 全文 " + full.length + " 字（未选中，将处理全文）";
    else el.textContent = "📄 " + ctx.doc.name + " · 暂无可提取文本";
  }
  function renderAICards() {
    const wrap = $("#ai-cards"); wrap.innerHTML = "";
    Object.keys(OS.AI.MODES).forEach(m => {
      const b = document.createElement("button");
      b.className = "ai-card"; b.dataset.mode = m;
      b.innerHTML = '<span class="ai-card-label">' + OS.AI.MODES[m].label + '</span><span class="ai-card-hint">' + OS.AI.MODES[m].hint + '</span>';
      b.onclick = () => runAI(m, "");
      wrap.appendChild(b);
    });
    const free = document.createElement("button");
    free.className = "ai-card ai-card-free"; free.dataset.mode = "";
    free.innerHTML = '<span class="ai-card-label">自由提问</span><span class="ai-card-hint">直接对话</span>';
    free.onclick = () => $("#ai-text").focus();
    wrap.appendChild(free);
  }
  function openAI() {
    const d = $("#ai-drawer"); d.hidden = false;
    refreshAIContext(); renderAICards();
    const chat = $("#ai-chat");
    if (!chat.querySelector(".ai-welcome")) {
      chat.innerHTML = '<div class="ai-welcome"><p>我是你的办公助手，可以帮你 <b>总结、润色、改写、扩写、续写、生成大纲、翻译、解释</b> 文档内容。</p><p class="muted">选中文字后点指令可针对选区处理；不选中则处理全文；也可直接提问。本地引擎离线可用，配置云端后自动升级。</p></div>';
    }
    setTimeout(() => $("#ai-text").focus(), 30);
  }
  function closeAI() { $("#ai-drawer").hidden = true; }
  function addChatBubble(role, text) {
    const chat = $("#ai-chat");
    const welcome = chat.querySelector(".ai-welcome"); if (welcome) welcome.remove();
    const b = document.createElement("div");
    b.className = "ai-msg ai-msg-" + role;
    const inner = document.createElement("div");
    inner.className = "ai-bubble";
    inner.textContent = text || (role === "ai" ? "正在思考…" : "");
    b.appendChild(inner);
    chat.appendChild(b);
    chat.scrollTop = chat.scrollHeight;
    return inner;
  }
  function typewriter(el, text, ctx, mode) {
    el.textContent = "";
    let i = 0;
    const step = Math.max(1, Math.round(text.length / 70));
    const timer = setInterval(() => {
      i += step; el.textContent = text.slice(0, i);
      const chat = $("#ai-chat"); if (chat) chat.scrollTop = chat.scrollHeight;
      if (i >= text.length) {
        clearInterval(timer); el.textContent = text;
        if (ctx && text && text.trim() && mode !== "translate" && mode !== "explain") {
          const bar = document.createElement("div"); bar.className = "ai-actions";
          const ins = document.createElement("button"); ins.className = "btn small";
          ins.textContent = "插入到文档";
          ins.onclick = () => { if (ctx.insertText(text)) OS.toast("已插入到文档", "ok"); };
          bar.appendChild(ins);
          el.appendChild(bar);
        }
      }
    }, 12);
  }
  async function runAI(mode, instruction) {
    const ctx = aiContext();
    let basis = "", srcLabel = "";
    if (ctx) {
      const sel = ctx.selText();
      if (sel) { basis = sel; srcLabel = "选中文本"; }
      else { basis = ctx.fullText(); srcLabel = "全文"; }
    }
    const user = basis
      ? (instruction ? instruction + "\n\n【" + srcLabel + "】\n" + basis : basis)
      : (instruction || "");
    addChatBubble("user", instruction || (mode ? OS.AI.MODES[mode].label : "提问"));
    const aiBubble = addChatBubble("ai", "");
    const msgEl = aiBubble.parentElement;
    const status = document.createElement("div");
    status.className = "ai-status";
    status.textContent = "⏳ 生成中…";
    msgEl.appendChild(status);
    try {
      const sys = AI_SYS[mode] || "你是绿角犀 Office 的智能助手，擅长中文办公场景的文档处理。";
      const acc = { text: "", source: "local" };
      const res = await OS.AI.run({
        mode, system: sys, user, allowCloud: true,
        onDelta: d => {
          acc.text += d;
          aiBubble.textContent = acc.text;
          const chat = $("#ai-chat"); if (chat) chat.scrollTop = chat.scrollHeight;
        }
      });
      acc.text = res.text; acc.source = res.source;
      aiBubble.textContent = res.text;
      status.textContent = res.source === "cloud" ? "☁ 云端模型 · 已流式输出" : "🖥 本地引擎 · 离线可用";
      status.classList.add("ai-status-" + res.source);
      if (ctx && res.text && res.text.trim()) addAIActions(msgEl, res.text, ctx, mode);
    } catch (e) {
      aiBubble.textContent = "出错了：" + e.message;
      status.textContent = "⚠ 生成失败";
    }
  }
  function addAIActions(msgEl, text, ctx, mode) {
    const bar = document.createElement("div"); bar.className = "ai-actions";
    const ins = document.createElement("button"); ins.className = "btn small"; ins.textContent = "插入到文档";
    ins.onclick = () => { if (ctx.insertText(text)) OS.toast("已插入到文档", "ok"); };
    const rep = document.createElement("button"); rep.className = "btn small"; rep.textContent = "替换选区";
    rep.onclick = () => {
      if (ctx.replaceSelection(text)) OS.toast("已替换选区", "ok");
      else OS.toast("请先在文档中选中要替换的文本", "warn");
    };
    bar.appendChild(ins); bar.appendChild(rep);
    msgEl.appendChild(bar);
  }
  function aiSend() {
    const ta = $("#ai-text"); const v = ta.value.trim(); if (!v) return;
    ta.value = "";
    runAI("", v);
  }

  /* ---------------- 登录系统 ---------------- */
  let backupTimer = null;

  function showLogin() { const ov = $("#login-overlay"); if (ov) ov.hidden = false; const u = $("#login-user"); if (u) setTimeout(() => u.focus(), 0); }
  function hideLogin() { const ov = $("#login-overlay"); if (ov) ov.hidden = true; }
  function downloadSpace(data, filename) {
    const json = JSON.stringify(data);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename || ("lvjiaoxi-space-" + Date.now() + ".lvjx");
    document.body.appendChild(a); a.click();
    setTimeout(() => { try { document.body.removeChild(a); } catch (e) { console.error("[Shell] 操作失败:", e); } URL.revokeObjectURL(url); }, 0);
  }

  async function enterApp() {
    await OS.store.init();
    startBackupTimer();
    try { OS.CloudSync && OS.CloudSync.start(); } catch (e) { console.error("cloudsync start failed", e); }
    try { OS.updater && OS.updater.start(); } catch (e) { console.error("updater start failed", e); }
    renderDashboard();
  }

  function startBackupTimer() {
    stopBackupTimer();
    const iv = (OS.auth && OS.auth.BACKUP_INTERVAL) || (5 * 60 * 1000);
    backupTimer = setInterval(async () => {
      try {
        const docs = await OS.store.list();
        if (!docs.length) return;
        if ((await OS.store.spaceUsed()) >= OS.store.quota()) await pruneOldestBackups();
        const n = await OS.store.backupAll(docs);
        if (n) OS.toast("已自动备档 " + n + " 个文档", "ok");
        // 云端账户：把本次备档同步到个人云（失败静默，不阻塞）
        try { if (OS.CloudSync && OS.CloudSync._state.enabled) OS.CloudSync.syncNow(); } catch (e) { console.error("[Shell] 操作失败:", e); }
      } catch (e) { console.error("auto-backup failed", e); }
    }, iv);
  }
  function stopBackupTimer() { if (backupTimer) { clearInterval(backupTimer); backupTimer = null; } }

  // 空间告急时清理最旧的一半备档
  async function pruneOldestBackups() {
    const all = (await OS.store.listAllBackups()).sort((a, b) => a.createdAt - b.createdAt);
    const oldest = all.slice(0, Math.ceil(all.length / 2));
    for (const b of oldest) await OS.store.removeBackup(b.id);
  }

  async function onLogin() {
    const msg = $("#login-msg");
    if (msg) msg.textContent = "";
    try {
      const rm = $("#remember-me");
      const sess = await OS.auth.login($("#login-user").value, $("#login-pass").value, rm ? rm.checked : false);
      if (msg) {
        if (sess.token) msg.textContent = "✓ 已登录，云端同步已激活";
        else msg.textContent = "✓ 已登录（离线模式，个人云同步将在连网后可用）";
      }
      afterLogin();
    }
    catch (e) { if (msg) msg.textContent = "✗ " + e.message; }
  }
  async function onRegister() {
    const msg = $("#login-msg");
    if (msg) msg.textContent = "";
    try {
      const rm = $("#remember-me");
      const sess = await OS.auth.register($("#login-user").value, $("#login-pass").value, rm ? rm.checked : false);
      if (msg) {
        if (sess.token) msg.textContent = "✓ 注册成功，云端同步已激活";
        else msg.textContent = "✓ 注册成功（离线模式，个人云同步将在连网后可用）";
      }
      afterLogin();
    }
    catch (e) { if (msg) msg.textContent = "✗ " + e.message; }
  }
  function afterLogin() { hideLogin(); enterApp(); }
  async function doLogout() {
    stopBackupTimer();
    try { OS.CloudSync && OS.CloudSync.stop(); } catch (e) { console.error("cloudsync stop failed", e); }
    await OS.auth.logout();
    const ov = $("#acct-overlay"); if (ov) ov.hidden = true;
    showLogin();
  }

  async function renderSpace(body) {
    const used = await OS.store.spaceUsed();
    const docB = await OS.store.docBytes();
    const bkB = await OS.store.backupBytes();
    const quota = OS.store.quota();
    const pct = Math.min(100, (used / quota) * 100);
    const fill = body.querySelector("#space-fill");
    const txt = body.querySelector("#space-text");
    if (fill) { fill.style.width = pct.toFixed(1) + "%"; fill.classList.toggle("warn", pct > 80); fill.classList.toggle("danger", pct > 95); }
    if (txt) txt.textContent = "已用 " + OS.util.fmtSize(used) + " / " + OS.util.fmtSize(quota) +
      "（文档 " + OS.util.fmtSize(docB) + " · 备档 " + OS.util.fmtSize(bkB) + "）" +
      (pct > 95 ? "（空间即将用尽）" : pct > 80 ? "（含备档占用，建议导出到外部）" : "");
  }
  async function renderBackups(body) {
    const list = await OS.store.listAllBackups();
    const box = body.querySelector("#bk-list");
    if (!box) return;
    if (!list.length) { box.innerHTML = '<p class="muted" style="font-size:12px">暂无备档。</p>'; return; }
    box.innerHTML = list.slice(0, 30).map(b => `
      <div class="bk-item">
        <div class="bk-meta"><b>${OS.util.escapeHtml(b.docName || b.docId)}</b><span class="muted">${OS.util.fmtTime(b.createdAt)}</span></div>
        <button class="btn tiny" data-restore="${b.id}">回滚</button>
      </div>`).join("");
    box.querySelectorAll("[data-restore]").forEach(btn => btn.onclick = async () => {
      try { const d = await OS.store.restoreBackup(btn.dataset.restore); OS.toast("已回滚：" + (d.name || d.id), "ok"); renderSpace(body); renderBackups(body); }
      catch (e) { OS.toast("回滚失败：" + e.message, "danger"); }
    });
  }

  /* ---------------- 账户/设置抽屉 ---------------- */
  function openAccount() {
    const s = OS.settings.all();
    const ov = $("#acct-overlay"); ov.hidden = false;
    const body = $("#acct-body");
    body.innerHTML = `
      <div class="setting-row"><div><div class="sr-label">数据不出域</div><div class="sr-desc">开启后 AI 等功能仅使用本地模型，数据不发送到云端（PRD 3.6.5）</div></div>
        <label class="switch"><input type="checkbox" id="set-local" ${s.dataLocalOnly ? "checked" : ""}><span class="slider"></span></label></div>
      <div class="setting-row"><div><div class="sr-label">自动保存</div><div class="sr-desc">编辑后自动写入本地存储</div></div>
        <label class="switch"><input type="checkbox" id="set-auto" ${s.autosave ? "checked" : ""}><span class="slider"></span></label></div>
      <div class="setting-row"><div><div class="sr-label">启动时要求登录</div><div class="sr-desc">默认关闭——游客可直接进入并使用全部本地功能。开启后每次启动需先登录（离线本地账户即可）。</div></div>
        <label class="switch"><input type="checkbox" id="set-reqlogin" ${s.requireLogin ? "checked" : ""}><span class="slider"></span></label></div>
      <h3 class="sr-h">AI 云端（可选增强）</h3>
      <p class="sr-desc">配置后 AI 助手自动升级为真实大模型流式响应。开启「数据不出域」时仍优先本地。配置仅保存在本机。</p>
      <div class="setting-row"><div><div class="sr-label">使用服务端 AI 代理（推荐自托管）</div><div class="sr-desc">经同源 /api/ai/chat 转发，真实 API Key 仅存于服务器（LVJX_AI_*），不暴露到本机浏览器。</div></div>
        <label class="switch"><input type="checkbox" id="set-ai-proxy"><span class="slider"></span></label></div>
      <div id="ai-manual-block">
        <p class="sr-desc">或手动填写自有 OpenAI 风格接口（密钥存本机浏览器，仅在你信任的设备使用）。</p>
        <div class="setting-row col"><div class="sr-label">接口地址</div><input id="ai-endpoint" class="bs-input" placeholder="https://api.openai.com/v1/chat/completions"></div>
        <div class="setting-row col"><div class="sr-label">API Key</div><input id="ai-key" type="password" class="bs-input" placeholder="sk-..."></div>
        <div class="setting-row col"><div class="sr-label">模型</div><input id="ai-model" class="bs-input" placeholder="gpt-4o-mini"></div>
      </div>
      <div class="bs-actions">
        <button class="btn" id="ai-test">测试连接</button>
        <button class="btn primary" id="ai-save">保存</button>
        <button class="btn" id="ai-clear">清除</button>
      </div>
      <p class="muted" id="ai-cfg-status" style="font-size:12px"></p>
      <hr style="border:none;border-top:1px solid var(--rule);margin:12px 0">
      <p class="muted" style="font-size:12px">存储模式：<b id="store-mode"></b></p>
      <p class="muted" style="font-size:12px" id="cloud-sync-status"></p>
      <p class="muted" style="font-size:12px">所有文档保存在本机（IndexedDB / 本地）。开启「数据不出域」后，内容不会离开此设备。</p>
      <hr style="border:none;border-top:1px solid var(--rule);margin:12px 0">
      <h3 class="sr-h">账户与空间</h3>
      <p class="muted" style="font-size:12px">当前账户：<b id="acct-name"></b> · <span id="acct-provider"></span></p>
      <div class="space-bar"><div class="space-fill" id="space-fill"></div></div>
      <p class="muted" style="font-size:12px" id="space-text"></p>
      <h3 class="sr-h" style="margin-top:10px">自动备档</h3>
      <p class="muted" style="font-size:12px">每 5 分钟自动备档（保留最近 ${(OS.auth && OS.auth.MAX_BACKUPS) || 20} 份/文档），计入个人空间。</p>
      <div class="bs-actions"><button class="btn" id="bk-now">立即备档</button><button class="btn" id="bk-refresh">刷新列表</button></div>
      <div id="bk-list" class="bk-list"></div>
      <hr style="border:none;border-top:1px solid var(--rule);margin:12px 0">
      <h3 class="sr-h" style="margin-top:10px">空间迁移 / 外部备份</h3>
      <p class="muted" style="font-size:12px">将全部文档与备档导出为 .lvjx 文件，可迁移到其它设备或作为外部备份（防本机丢失）。导入将合并到当前账户。</p>
      <div class="setting-row col"><div class="sr-label">导出加密口令（可选）</div><input id="sp-pass" type="password" class="bs-input" placeholder="留空则不加密；导入加密文件时会提示输入口令"></div>
      <div class="bs-actions"><button class="btn" id="sp-export">导出空间</button><button class="btn" id="sp-import">导入空间</button><input type="file" id="sp-import-file" accept=".lvjx,application/json" hidden></div>
      <p class="muted" id="sp-io-status" style="font-size:12px"></p>
      <hr style="border:none;border-top:1px solid var(--rule);margin:12px 0">
      <h3 class="sr-h" style="margin-top:10px">版本与更新</h3>
      <p class="muted" style="font-size:12px">当前版本：<b id="acct-version"></b> · <span id="acct-update-status" class="muted"></span></p>
      <div class="bs-actions"><button class="btn" id="acct-check-update">检查更新</button></div>
      <div class="bs-actions" style="margin-top:10px"><button class="btn danger" id="acct-logout">退出登录</button></div>`;
    body.querySelector("#set-local").onchange = e => OS.settings.set("dataLocalOnly", e.target.checked);
    body.querySelector("#set-auto").onchange = e => OS.settings.set("autosave", e.target.checked);
    const reqLoginEl = body.querySelector("#set-reqlogin");
    if (reqLoginEl) reqLoginEl.onchange = e => OS.AuthPolicy.setRequire(e.target.checked);
    const savedP = OS.AI.getProvider() || {};
    const useProxy = !!(OS.settings && OS.settings.get("aiUseProxy"));
    const proxyEl = body.querySelector("#set-ai-proxy");
    const manualBlock = body.querySelector("#ai-manual-block");
    if (proxyEl) proxyEl.checked = useProxy;
    const epEl = body.querySelector("#ai-endpoint"), keyEl = body.querySelector("#ai-key"), modelEl = body.querySelector("#ai-model"), cfgEl = body.querySelector("#ai-cfg-status");
    epEl.value = useProxy ? "" : (savedP.endpoint || ""); keyEl.value = savedP.apiKey || ""; modelEl.value = savedP.model || "";
    function syncManualBlock() { if (manualBlock) manualBlock.hidden = !!(proxyEl && proxyEl.checked); }
    syncManualBlock();
    if (proxyEl) proxyEl.onchange = () => { syncManualBlock(); };
    body.querySelector("#ai-save").onclick = () => {
      if (proxyEl && proxyEl.checked) {
        OS.AI.setProxyProvider(true, modelEl.value.trim() || "gpt-4o-mini");
        cfgEl.textContent = "✓ 已启用服务端 AI 代理：请求经 /api/ai/chat 转发，密钥留服务器。";
        return;
      }
      const cfg = { endpoint: epEl.value.trim(), apiKey: keyEl.value.trim(), model: modelEl.value.trim() || "gpt-4o-mini" };
      if (!cfg.endpoint) { cfgEl.textContent = "请填写接口地址，或勾选「使用服务端 AI 代理」。"; return; }
      OS.AI.setProxyProvider(false);
      OS.AI.setProvider(cfg);
      cfgEl.textContent = "✓ 已保存自有云端配置（仅本机），AI 助手将优先走真实流式模型。";
    };
    if (body.querySelector("#ai-clear")) body.querySelector("#ai-clear").onclick = () => {
      OS.AI.setProxyProvider(false);
      OS.AI.setProvider(null);
      epEl.value = ""; keyEl.value = ""; modelEl.value = "";
      if (proxyEl) proxyEl.checked = false; syncManualBlock();
      cfgEl.textContent = "已清除云端配置，AI 走本地引擎。";
    };
    body.querySelector("#ai-test").onclick = async () => {
      cfgEl.textContent = "正在测试连接…";
      try {
        const txt = await OS.AI.completeCloud({ system: "你是测试助手。", user: "请只回复：OK", onDelta: null });
        cfgEl.textContent = "✓ 连接成功，模型返回：" + (txt || "").slice(0, 40);
      } catch (e) { cfgEl.textContent = "✗ 连接失败：" + e.message; }
    };
    body.querySelector("#store-mode").textContent = OS._storeMode || "未知";
    const cur = OS.auth.current();
    const cloudStatus = body.querySelector("#cloud-sync-status");
    if (cloudStatus) {
      const cs = OS.CloudSync && OS.CloudSync.status ? OS.CloudSync.status() : null;
      if (cs && cs.enabled) {
        const when = cs.lastSync ? ("，上次同步 " + OS.util.fmtTime(cs.lastSync)) : "（同步中…）";
        cloudStatus.textContent = (cs.connected ? "☁ 已连接个人云" : "☁ 个人云未连通") + when + " · 备档可跨设备恢复";
      } else if (cur && cur.token) {
        cloudStatus.textContent = "☁ 云端账户（同步未激活，请确认服务器可达）";
      } else {
        cloudStatus.textContent = "本地账户：文档仅存于本机，建议定期导出 .lvjx 外部备份。";
      }
    }
    // 账户信息 + 空间 + 备档
    const nameEl = body.querySelector("#acct-name"); if (nameEl) nameEl.textContent = cur ? cur.username : "未登录";
    const provEl = body.querySelector("#acct-provider");
    if (provEl) provEl.textContent = cur ? (cur.token ? "云端已链接 · 自动同步" : "本地账户（离线）") : "";
    renderSpace(body);
    renderBackups(body);
    const bkNow = body.querySelector("#bk-now"); if (bkNow) bkNow.onclick = async () => { await OS.store.backupAll(); OS.toast("已备档", "ok"); renderSpace(body); renderBackups(body); };
    const bkRefresh = body.querySelector("#bk-refresh"); if (bkRefresh) bkRefresh.onclick = () => { renderSpace(body); renderBackups(body); };
    // 空间导出 / 导入
    const spStatus = body.querySelector("#sp-io-status");
    const spExport = body.querySelector("#sp-export");
    const spImport = body.querySelector("#sp-import");
    const spImportFile = body.querySelector("#sp-import-file");
    if (spExport) spExport.onclick = async () => {
      try {
        const spPass = body.querySelector("#sp-pass");
        const pass = spPass ? spPass.value : "";
        const data = await OS.store.exportSpace(pass ? { passphrase: pass } : {});
        const nm = "绿角犀空间-" + ((OS.auth.current() && OS.auth.current().username) || "anon") + "-" + new Date().toISOString().slice(0, 10) + ".lvjx";
        downloadSpace(data, nm);
        if (spStatus) spStatus.textContent = data.encrypted
          ? "✓ 已加密导出" + (data.hint ? "（账户 " + data.hint + "）" : "")
          : "✓ 已导出 " + data.docs.length + " 文档 / " + data.backups.length + " 备档";
        OS.toast("已导出个人空间" + (pass ? "（已加密）" : ""), "ok");
      } catch (e) { if (spStatus) spStatus.textContent = "✗ 导出失败：" + e.message; }
    };
    if (spImport) spImport.onclick = () => { if (spImportFile) spImportFile.click(); };
    if (spImportFile) spImportFile.onchange = async (ev) => {
      const f = ev.target.files && ev.target.files[0];
      if (!f) return;
      try {
        const text = await f.text();
        const data = JSON.parse(text);
        let pass = "";
        if (data.encrypted) { pass = window.prompt("该文件已加密，请输入导出口令："); if (pass === null) { spImportFile.value = ""; return; } }
        const r = await OS.store.importSpace(data, pass ? { passphrase: pass } : {});
        if (spStatus) spStatus.textContent = "✓ 已导入 " + r.docs + " 文档 / " + r.backups + " 备档";
        OS.toast("已导入个人空间", "ok");
        renderSpace(body); renderBackups(body);
        OS.bus && OS.bus.emit("docs-changed", {});
      } catch (e) { if (spStatus) spStatus.textContent = "✗ 导入失败：" + e.message; }
      spImportFile.value = "";
    };
    const logoutBtn = body.querySelector("#acct-logout"); if (logoutBtn) logoutBtn.onclick = () => doLogout();
    // 版本与更新
    const verEl = body.querySelector("#acct-version"); if (verEl) verEl.textContent = OS.version || (OS.updater && OS.updater.currentVersion()) || "?";
    const updStatus = body.querySelector("#acct-update-status");
    const checkBtn = body.querySelector("#acct-check-update");
    if (checkBtn) checkBtn.onclick = async () => {
      checkBtn.disabled = true;
      try {
        const r = await OS.updater.checkNow({ toast: true });
        if (updStatus) updStatus.textContent = r ? ("发现新版本 v" + r.version) : "已是最新";
      } finally { checkBtn.disabled = false; }
    };
    $("#acct-close").onclick = () => ov.hidden = true;
    ov.onclick = e => { if (e.target === ov) ov.hidden = true; };
  }

  // 启动
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  /* ---------------- 全局文档搜索（跨所有打开的文档） ---------------- */
  function snippet(text, q) {
    const t = String(text == null ? "" : text);
    const ql = (q || "").toLowerCase(); const tl = t.toLowerCase();
    const idx = tl.indexOf(ql);
    if (idx === -1 || !q) return OS.util.escapeHtml(t.slice(0, 80));
    const start = Math.max(0, idx - 30);
    const end = Math.min(t.length, idx + q.length + 30);
    const before = (start > 0 ? "…" : "") + t.slice(start, idx);
    const mid = t.slice(idx, idx + q.length);
    const after = t.slice(idx + q.length, end) + (end < t.length ? "…" : "");
    return OS.util.escapeHtml(before) + "<mark>" + OS.util.escapeHtml(mid) + "</mark>" + OS.util.escapeHtml(after);
  }
  // 跨文档检索：优先调用各模块的 search()，否则退化为整篇文本匹配
  function globalSearch(q, scope) {
    const out = [];
    if (!q || !q.trim()) return out;
    const list = (scope === "active" && activeTab()) ? [activeTab()] : tabs;
    list.forEach(t => {
      const inst = t.instance;
      if (inst && typeof inst.search === "function") {
        inst.search(q).forEach(r => out.push(Object.assign({ tab: t, docName: t.doc.name, docType: t.doc.type }, r)));
      } else {
        const full = getFullText(t.doc);
        if (full.toLowerCase().indexOf(q.toLowerCase()) !== -1) {
          out.push({ tab: t, docName: t.doc.name, docType: t.doc.type, label: "（整篇）", previewHtml: snippet(full, q), goto: null });
        }
      }
    });
    return out;
  }
  function openSearch() {
    let ov = document.getElementById("global-search-overlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "global-search-overlay"; ov.className = "overlay"; ov.hidden = true;
      ov.innerHTML = `
        <div class="gs-panel">
          <div class="gs-head">
            <span class="gs-title">${OS.icons.svg("search", 16)} 全局文档搜索</span>
            <button class="icon-btn" data-gs-close title="关闭">✕</button>
          </div>
          <div class="gs-bar">
            <input class="gs-input" placeholder="输入关键词，跨所有打开的文档检索…" />
            <div class="gs-scope">
              <button data-scope="all" class="on">全部文档</button>
              <button data-scope="active">当前文档</button>
            </div>
          </div>
          <div class="gs-count" id="gs-count"></div>
          <div class="gs-results" id="gs-results"></div>
        </div>`;
      document.body.appendChild(ov);
      _on(ov, "click", e => { if (e.target === ov || e.target.closest("[data-gs-close]")) closeSearch(); });
      const input = ov.querySelector(".gs-input");
      const resultsEl = ov.querySelector("#gs-results");
      const countEl = ov.querySelector("#gs-count");
      let scope = "all";
      ov.querySelectorAll(".gs-scope button").forEach(b => b.onclick = () => {
        ov.querySelectorAll(".gs-scope button").forEach(x => x.classList.remove("on"));
        b.classList.add("on"); scope = b.dataset.scope; render();
      });
      function render() {
        const q = input.value;
        const res = globalSearch(q, scope);
        countEl.textContent = q.trim() ? (res.length ? res.length + " 处匹配" : "无匹配") : "";
        resultsEl.innerHTML = "";
        if (!q.trim()) return;
        if (!res.length) { resultsEl.innerHTML = '<div class="gs-empty">没有匹配的文档内容</div>'; return; }
        res.forEach(r => {
          const info = OS.TYPE_INFO[r.docType] || { ico: "📄", name: r.docType };
          const item = document.createElement("button");
          item.className = "gs-item";
          item.innerHTML =
            `<span class="gs-doc">${info.ico} ${OS.util.escapeHtml(r.docName)}</span>` +
            `<span class="gs-label">${OS.util.escapeHtml(r.label || "")}</span>` +
            `<span class="gs-preview">${r.previewHtml || ""}</span>`;
          item.onclick = () => focusResult(r);
          resultsEl.appendChild(item);
        });
      }
      ov._render = render;
    }
    ov.hidden = false;
    const input = ov.querySelector(".gs-input"); input.value = ""; input.focus();
    if (ov._render) ov._render();
  }
  function closeSearch() { const ov = document.getElementById("global-search-overlay"); if (ov) ov.hidden = true; }
  function focusResult(r) {
    if (r.tab) activate(r.tab);
    if (r.goto) { try { r.goto(); } catch (e) { console.error("[Shell] 操作失败:", e); } }
    closeSearch();
    if (r.tab) renderStatusbar();
  }

  /* ---------------- 跨文档查找替换（Ctrl/Cmd+H） ---------------- */
  // 遍历指定范围（当前文档 / 全部打开的文档）的模块 replaceAll，返回统计
  function globalReplace(q, replacement, opts, scope) {
    if (!q || !q.trim()) return { docs: 0, count: 0 };
    const list = (scope === "active" && activeTab()) ? [activeTab()] : tabs;
    let docs = 0, count = 0;
    list.forEach(t => {
      const inst = t.instance;
      if (inst && typeof inst.replaceAll === "function") {
        const n = inst.replaceAll(q, replacement, opts);
        if (n) { docs++; count += n; }
      }
    });
    return { docs, count };
  }
  function openReplace() {
    let ov = document.getElementById("replace-overlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "replace-overlay"; ov.className = "overlay"; ov.hidden = true;
      ov.innerHTML = `
        <div class="gs-panel">
          <div class="gs-head">
            <span class="gs-title">${OS.icons.svg("replace", 16)} 查找替换</span>
            <button class="icon-btn" data-rp-close title="关闭">✕</button>
          </div>
          <div class="gs-bar" style="flex-direction:column;align-items:stretch;gap:8px">
            <input class="gs-input" id="rp-find" placeholder="查找内容…" />
            <input class="gs-input" id="rp-repl" placeholder="替换为（留空表示删除）…" />
            <div class="gs-scope" style="justify-content:flex-start;gap:12px">
              <label class="rp-case"><input type="checkbox" id="rp-case" /> 区分大小写</label>
              <button data-scope="active">当前文档</button>
              <button data-scope="all" class="on">全部打开的文档</button>
            </div>
          </div>
          <div class="gs-count" id="rp-count"></div>
          <div class="gs-results" style="padding-top:8px">
            <button class="btn primary" data-rp-do style="width:100%">替换全部</button>
          </div>
        </div>`;
      document.body.appendChild(ov);
      _on(ov, "click", e => { if (e.target === ov || e.target.closest("[data-rp-close]")) closeReplace(); });
      const findEl = ov.querySelector("#rp-find");
      const replEl = ov.querySelector("#rp-repl");
      const countEl = ov.querySelector("#rp-count");
      const caseEl = ov.querySelector("#rp-case");
      let scope = "all";
      ov.querySelectorAll(".gs-scope [data-scope]").forEach(b => b.onclick = () => {
        ov.querySelectorAll(".gs-scope [data-scope]").forEach(x => x.classList.remove("on"));
        b.classList.add("on"); scope = b.dataset.scope;
      });
      ov._replace = () => {
        const q = findEl.value;
        const opts = { matchCase: caseEl.checked };
        const res = globalReplace(q, replEl.value, opts, scope);
        countEl.textContent = q.trim()
          ? (res.count ? `已在 ${res.docs} 个文档中替换 ${res.count} 处` : "没有可替换的内容")
          : "";
        if (res.count) OS.toast(`替换 ${res.count} 处（${res.docs} 个文档）`, "ok");
      };
      ov.querySelector("[data-rp-do]").onclick = () => ov._replace();
      _on(findEl, "keydown", e => { if (e.key === "Enter") ov._replace(); });
      _on(replEl, "keydown", e => { if (e.key === "Enter") ov._replace(); });
    }
    ov.hidden = false;
    ov.querySelector("#rp-find").focus();
  }
  function closeReplace() { const ov = document.getElementById("replace-overlay"); if (ov) ov.hidden = true; }

    OS.shell = { boot, newDoc, openDoc, saveNow, openBackstage, closeBackstage, globalSearch, openSearch, closeSearch, openReplace, closeReplace, globalReplace, snippet, openPdfToolbox: () => OS.PDFToolbox && OS.PDFToolbox.open() };

  // ===== PDF 工具箱入口按钮 =====
  document.getElementById('btn-pdf-toolbox')?.addEventListener('click', () => {
    OS.PDFToolbox && OS.PDFToolbox.open();
  });
})(window);
