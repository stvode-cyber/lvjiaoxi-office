/* ============================================================
   绿角犀 Office · 结构化文件导入 (OOXML / ODF / OFD)
   对应 PRD：3.1 兼容性矩阵 / 附录 A 数据模型
   - 用 DOMParser 解析 OOXML(docx/xlsx/pptx)、ODF(odt/ods/odp)、OFD(ofd 国标 GB/T 33190)
   - 保留标题层级、粗体/斜体/下划线、项目符号、表格、超链接、公式、版式坐标
   - 导入结果直接映射到 writer / spreadsheet / presentation 的 data 结构
   - OFD 为固定版式（类似 PDF），按页面映射到 Presentation 幻灯片（每页一张、文本按毫米坐标定位）
   - 兼容等级标记为 B（基本兼容，非像素级保真）
   依赖：JSZip（在线时由 index.html 注入；file:// 离线可用内存兜底）
   ============================================================ */
(function (global) {
  "use strict";
  // TODO: [坑-parseXmind-国际化title] 预防: title 字段先 typeof === 'string' 再 .trim()，否则取 .default 或 .zh-CN
  // TODO: [坑-mindmap-NaN-path] 预防: 同 mindmap.js — 孤立节点坐标给 fallback
  // TODO: [坑-fileassoc-hardcoded-absolute] 预防: 同 shell.js
  const OS = global.OS;
  // Electron contextIsolation: true + nodeIntegration: false 下，
  // 第三方库只挂到 window.XLSX / window.JSZip，不挂到 Node global。
  // 用 typeof 守卫 + window 优先 + globalThis 兜底，兼容浏览器/Electron/jsdom/纯 Node 单测。
  // TODO: [坑-electron-global-window] 预防：Electron contextIsolation 下 global ≠ window，第三方库查找必须 window 优先 + globalThis 兜底
  function _pickLib(name) {
    if (typeof window !== "undefined" && window[name]) return window[name];
    if (typeof globalThis !== "undefined" && globalThis[name]) return globalThis[name];
    if (typeof global !== "undefined" && global !== window && global[name]) return global[name];
    return null;
  }
  // TODO: [坑-xmind-import-卡死] 预防：所有异步步骤必须有 timeout 兜底，防止 Promise 永不 settle 导致 Tasks.run 卡死
  function withTimeout(promise, ms, label) {
    return new Promise((resolve, reject) => {
      const to = setTimeout(() => reject(new Error((label || "async op") + " 超时（" + ms + "ms）")), ms);
      promise.then(r => { clearTimeout(to); resolve(r); }, e => { clearTimeout(to); reject(e); });
    });
  }
  const JSZip = _pickLib("JSZip");
  // ★ 懒加载：XLSX（SheetJS）不再顶层加载 — 改在 importFile() 的 .xls 分支按需 await OS.LazyLib.load("XLSX")
  let XLSX = null;

  /* ---------- 通用 XML/DOM 工具 ---------- */
  function parseXML(str) {
    const d = new DOMParser().parseFromString(str, "application/xml");
    if (d.querySelector("parsererror")) throw new Error("XML 解析失败");
    return d;
  }
  const all = (el, name) => el ? Array.from(el.getElementsByTagNameNS("*", name)) : [];
  const first = (el, name) => el ? el.getElementsByTagNameNS("*", name)[0] || null : null;
  // 聪明的 attr：先 getAttribute(name)，找不到再按 localName 遍历（处理 r:embed 等带 ns 前缀的属性）
  const attr = (el, name) => {
    if (!el) return null;
    let v = el.getAttribute(name);
    if (v != null) return v;
    for (const a of (el.attributes || [])) {
      if (a.localName === name) return a.value;
    }
    return null;
  };
  function esc(s) {
    if (s == null) return "";
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function escAttr(s) {
    return esc(s).replace(/"/g, "&quot;");
  }
  function colToIdx(col) { // "AB" -> 28
    let n = 0; for (let i = 0; i < col.length; i++) n = n * 26 + (col.charCodeAt(i) - 64); return n;
  }
  function refToRC(ref) { const m = /^([A-Z]+)(\d+)$/.exec(ref); return m ? { c: colToIdx(m[1]), r: +m[2] } : { c: 1, r: 1 }; }
  function isNum(v) { return v !== "" && v != null && !isNaN(+v); }

  /* ---------- DOCX 内嵌图片读回（drawing/blip r:embed → word/media → data URI）---------- */
  let IMG_EMBED = {};   // rId -> "data:image/...;base64,..."  ，每轮 parseDocx 重置
  function mimeFromPath(p) {
    const e = (p.split(".").pop() || "").toLowerCase();
    if (e === "jpg" || e === "jpeg") return "image/jpeg";
    if (e === "gif") return "image/gif";
    if (e === "webp") return "image/webp";
    if (e === "bmp") return "image/bmp";
    return "image/png";
  }
  function drawingToImg(node) {
    const blip = first(node, "blip");
    if (!blip) return "";
    const id = attr(blip, "r:embed");
    const uri = id && IMG_EMBED[id];
    return uri ? `<img src="${escAttr(uri)}" alt="导入图片">` : "";
  }
  // 预读 document.xml 中所有 blip 引用的媒体，转 data URI 缓存（zip 读字节为异步，故在 parseDocx 入口统一预取）
  async function prefetchDocxImages(d, rels, zip) {
    IMG_EMBED = {};
    const blips = all(d.documentElement, "blip");
    await Promise.all(blips.map(async bl => {
      const id = attr(bl, "r:embed");
      if (!id) return;
      const target = rels[id];
      if (!target) return;
      let p = target;
      if (p.charAt(0) === "/") p = p.slice(1);
      else if (p.indexOf("word/") !== 0) {
        p = p.replace(/^\.\//, "");
        if (p.indexOf("word/") !== 0) p = "word/" + p;
      }
      const f = zip.file(p);
      if (!f) return;
      try {
        const b64 = await f.async("base64");
        IMG_EMBED[id] = "data:" + mimeFromPath(p) + ";base64," + b64;
      } catch (e) { /* 读取失败优雅跳过，不阻断整篇导入 */ }
    }));
  }

  /* ============================================================
     DOCX -> Writer HTML
     ============================================================ */
  async function parseDocx(zip) {
    console.time("[DOCX] parseDocx 总耗时");
    console.time("[DOCX] 1. I/O 预读");
    // document.xml + rels + comments + numbering 4 路 I/O 并行
    const [docXml, relsXml, commentDefs, numFmt] = await Promise.all([
      zip.file("word/document.xml").async("string"),
      zip.file("word/_rels/document.xml.rels") ? zip.file("word/_rels/document.xml.rels").async("string") : Promise.resolve(null),
      parseComments(zip),
      buildNumbering(zip)
    ]);
    const rels = parseRels(relsXml);
    console.timeEnd("[DOCX] 1. I/O 预读");

    console.time("[DOCX] 2. XML 解析 + 图片预读");
    const d = parseXML(docXml);
    await prefetchDocxImages(d, rels, zip);
    console.timeEnd("[DOCX] 2. XML 解析 + 图片预读");

    console.time("[DOCX] 3. DOM 遍历");
    const body = first(d.documentElement, "body");
    if (!body) throw new Error("未找到文档正文");

    let html = "";
    let listBuf = null;
    const state = { stack: [], quotes: {} };
    const flushList = () => {
      if (listBuf) { html += `<${listBuf.type}>` + listBuf.items.map(i => `<li>${i}</li>`).join("") + `</${listBuf.type}>`; listBuf = null; }
    };

    for (const node of Array.from(body.children)) {
      const tag = node.localName;
      if (tag === "p") {
        const blk = blockFromP(node, rels, numFmt, state);
        if (blk.isList) {
          if (!listBuf || listBuf.type !== blk.listType) { flushList(); listBuf = { type: blk.listType, items: [] }; }
          listBuf.items.push(blk.inner);
        } else { flushList(); html += blk.outer; }
      } else if (tag === "tbl") { flushList(); html += tableToHtml(node, rels, state); }
    }
    flushList();

    /* ---------- 组装批注（优先用正文引用跨度取 quote）---------- */
    const comments = [];
    Object.keys(commentDefs.byId).map(Number).sort((a, b) => a - b).forEach(wid => {
      const def = commentDefs.byId[wid];
      if (def.parentId != null) return; // 回复在下方聚合
      const quote = (state.quotes[wid] != null && state.quotes[wid] !== "") ? state.quotes[wid] : def.firstLine;
      const replies = (commentDefs.repliesByParent[wid] || []).map(r => ({
        author: r.author || "我", text: r.text || "", createdAt: r.date ? (Date.parse(r.date) || Date.now()) : Date.now()
      }));
      comments.push({
        id: String(wid), quote: quote || "", text: def.firstLine || "", author: def.author || "我",
        createdAt: def.date ? (Date.parse(def.date) || Date.now()) : Date.now(),
        resolved: !!def.done, replies
      });
    });

    console.timeEnd("[DOCX] 3. DOM 遍历");
    console.timeEnd("[DOCX] parseDocx 总耗时");
    return { type: "writer", data: { html: html || "<p>（空文档）</p>", comments }, compat: "B", note: "DOCX 已导入（基本兼容：标题/格式/列表/表格/链接/批注保留）" };
  }

  async function parseComments(zip) {
    const byId = {}; const repliesByParent = {};
    const f = zip.file("word/comments.xml");
    if (!f) return { byId, repliesByParent };
    const xml = await f.async("string");
    const d = parseXML(xml);
    all(d.documentElement, "comment").forEach(c => {
      const wid = attr(c, "w:id");
      const parentId = attr(c, "w:parentId");
      const author = attr(c, "w:author") || "我";
      const date = attr(c, "w:date") || null;
      const done = attr(c, "w:done") === "1" || attr(c, "w:done") === "true";
      let text = "";
      all(c, "t").forEach(t => { text += t.textContent; });
      if (parentId != null) {
        (repliesByParent[parentId] = repliesByParent[parentId] || []).push({ author, date, text });
      } else {
        byId[wid] = { author, date, done, firstLine: text };
      }
    });
    return { byId, repliesByParent };
  }

  function blockFromP(pEl, rels, numFmt, state) {
    const pPr = first(pEl, "pPr");
    let tag = "p", isList = false, listType = "ul";
    const pStyles = [];  // 段落级 CSS
    if (pPr) {
      const ps = first(pPr, "pStyle");
      if (ps) {
        const v = attr(ps, "w:val") || "";
        const m = /Heading(\d)/.exec(v);
        if (m) tag = "h" + m[1];
        else if (/^Title$/i.test(v)) tag = "h1";
        else if (/^Subtitle$/i.test(v)) tag = "h2";
      }
      // 对齐
      const jc = first(pPr, "jc");
      if (jc) {
        const jv = attr(jc, "w:val") || "left";
        const jMap = { left: "left", center: "center", right: "right", both: "justify", distribute: "justify", start: "left", end: "right" };
        const align = jMap[jv] || "left";
        if (align !== "left") pStyles.push("text-align:" + align);
      }
      // 缩进（twips → px: val/1440 * 96）
      const ind = first(pPr, "ind");
      if (ind) {
        const firstLine = attr(ind, "w:firstLine");
        if (firstLine) pStyles.push("text-indent:" + Math.round((+firstLine) / 1440 * 96) + "px");
        const left = attr(ind, "w:left") || attr(ind, "w:leftChars");
        if (left) pStyles.push("padding-left:" + Math.round((+left) / 1440 * 96) + "px");
        const right = attr(ind, "w:right") || attr(ind, "w:rightChars");
        if (right) pStyles.push("padding-right:" + Math.round((+right) / 1440 * 96) + "px");
      }
      // 段间距 + 行间距
      const spacing = first(pPr, "spacing");
      if (spacing) {
        const before = attr(spacing, "w:before");
        if (before) pStyles.push("margin-top:" + Math.round((+before) / 1440 * 96) + "px");
        const after = attr(spacing, "w:after");
        if (after) pStyles.push("margin-bottom:" + Math.round((+after) / 1440 * 96) + "px");
        const line = attr(spacing, "w:line");
        const lineRule = attr(spacing, "w:lineRule");
        if (line) {
          // lineRule=auto → line/240 是倍数；否则 line 是 twips → px
          let lh;
          if (lineRule === "auto") lh = ((+line) / 240).toFixed(2);
          else lh = Math.round((+line) / 1440 * 96) + "px";
          pStyles.push("line-height:" + lh);
        }
      }
      const numPr = first(pPr, "numPr");
      if (numPr) {
        isList = true;
        const numId = attr(first(numPr, "numId"), "w:val");
        listType = (numId && numFmt[numId]) || "ul";
      }
    }
    const inner = runsToHtml(pEl, rels, state);
    // 段落结束关闭仍未闭合的批注跨度（跨段批注降级为单段闭合）
    let closeHtml = "";
    while (state.stack.length) { state.stack.pop(); closeHtml += "</span>"; }
    const fullInner = inner + closeHtml;
    if (isList) return { isList: true, listType, inner: fullInner };
    const styleAttr = pStyles.length ? ` style="${pStyles.join(";")}"` : "";
    return { isList: false, outer: `<${tag}${styleAttr}>${fullInner || "<br>"}</${tag}>` };
  }

  function runsToHtml(el, rels, state) {
    state = state || { stack: [], quotes: {} };
    let out = "";
    for (const n of Array.from(el.childNodes)) {
      if (n.nodeType === 3) {
        const tv = n.nodeValue;
        if (tv) {
          if (state.stack.length) state.quotes[state.stack[state.stack.length - 1].wid] += tv;
          out += esc(tv);
        }
        continue;
      }
      const tag = n.localName;
      if (tag === "r") {
        if (first(n, "commentReference")) continue; // 跳过批注引用锚点（无可见文字）
        out += runToHtml(n);
        if (state.stack.length) state.quotes[state.stack[state.stack.length - 1].wid] += (n.textContent || "");
      }
      else if (tag === "hyperlink") out += hyperlinkToHtml(n, rels, state);
      else if (tag === "tab") out += "    ";
      else if (tag === "br") out += "<br>";
      else if (tag === "commentRangeStart") {
        const wid = attr(n, "w:id");
        state.stack.push({ wid: wid });
        if (state.quotes[wid] == null) state.quotes[wid] = "";
        out += '<span class="cmt" data-cid="' + wid + '">';
      }
      else if (tag === "commentRangeEnd") {
        out += "</span>";
        if (state.stack.length) state.stack.pop();
      }
      else out += runsToHtml(n, rels); // smartTag / ins / customXml 等容器
    }
    return out;
  }

  function runToHtml(rEl) {
    const rPr = first(rEl, "rPr");
    let txt = "";
    let imgHtml = "";
    for (const n of Array.from(rEl.childNodes)) {
      const t = n.localName;
      if (t === "t") txt += n.textContent;
      else if (t === "tab") txt += "    ";
      else if (t === "br") txt += "\n";
      else if (t === "noBreakHyphen") txt += "-";
      else if (t === "drawing") { const im = drawingToImg(n); if (im) imgHtml += im; }
    }
    txt = esc(txt).replace(/\n/g, "<br>");
    let s = txt;
    if (imgHtml) s += imgHtml;   // 内嵌图片不参与 esc，直接拼为 <img>
    if (rPr) {
      // 先处理 sup/sub（外层包裹，因为是定位属性）
      const va = first(rPr, "vertAlign");
      const vaVal = va ? attr(va, "w:val") : null;
      if (vaVal === "superscript") s = `<sup>${s}</sup>`;
      else if (vaVal === "subscript") s = `<sub>${s}</sub>`;
      // 收集所有内联样式到一个 <span style="...">，避免多层嵌套
      const styles = [];
      const b = first(rPr, "b"); if (b) styles.push("font-weight:700");
      const it = first(rPr, "i"); if (it) styles.push("font-style:italic");
      const u = first(rPr, "u"); if (u) styles.push("text-decoration:underline");
      const st = first(rPr, "strike"); if (st) styles.push("text-decoration:line-through");
      // fontSize: w:sz 是子元素 <w:sz w:val="48"/>，val 是 half-points → px = val/2 * 1.333
      const szEl = first(rPr, "sz");
      const sz = szEl ? attr(szEl, "val") : null;
      if (sz) {
        const px = Math.round((+sz) / 2 * 1.333);
        styles.push("font-size:" + px + "px");
      }
      // fontFamily: 优先 eastAsia（中文），fallback ascii
      const rFonts = first(rPr, "rFonts");
      if (rFonts) {
        const ea = attr(rFonts, "w:eastAsia") || attr(rFonts, "w:cs");
        const ascii = attr(rFonts, "w:ascii");
        const fontFamily = (ea || ascii || "").replace(/"/g, "");
        if (fontFamily) styles.push("font-family:\"" + fontFamily + "\",system-ui,sans-serif");
      }
      // color
      const colorEl = first(rPr, "color");
      const color = colorEl ? attr(colorEl, "w:val") : null;
      if (color && /^[0-9a-fA-F]{6}$/.test(color)) styles.push("color:#" + color);
      // highlight → background-color
      const hl = first(rPr, "highlight");
      if (hl) {
        const hlVal = attr(hl, "w:val");
        if (hlVal && hlVal !== "none") {
          const hlMap = { yellow: "#ffff00", green: "#00ff00", cyan: "#00ffff", magenta: "#ff00ff", blue: "#0000ff", red: "#ff0000", darkBlue: "#00008b", darkCyan: "#008b8b", darkGreen: "#006400", darkMagenta: "#8b008b", darkRed: "#8b0000", darkYellow: "#8b8b00", darkGray: "#a9a9a9", lightGray: "#d3d3d3", black: "#000000", white: "#ffffff" };
          const cssColor = hlMap[hlVal] || hlVal;
          styles.push("background-color:" + cssColor);
        }
      }
      if (styles.length) s = `<span style="${styles.join(";")}">${s}</span>`;
    }
    return s;
  }

  function hyperlinkToHtml(hEl, rels, state) {
    const rid = attr(hEl, "r:id");
    const href = rels[rid] || "#";
    const inner = runsToHtml(hEl, rels, state);
    return `<a href="${escAttr(href)}">${inner}</a>`;
  }

  function tableToHtml(tblEl, rels, state) {
    const rows = all(tblEl, "tr").map(tr => {
      const tds = all(tr, "tc").map(tc => `<td>${runsToHtml(tc, rels, state)}</td>`).join("");
      return `<tr>${tds}</tr>`;
    }).join("");
    return `<table class="imp-table"><tbody>${rows}</tbody></table>`;
  }

  function parseRels(xml) {
    const map = {};
    if (!xml) return map;
    const d = parseXML(xml);
    all(d.documentElement, "Relationship").forEach(r => { map[attr(r, "Id")] = attr(r, "Target"); });
    return map;
  }

  async function buildNumbering(zip) {
    const map = {};
    const f = zip.file("word/numbering.xml");
    if (!f) return map;
    try {
      const d = parseXML(await f.async("string"));
      const abs = {};
      all(d.documentElement, "abstractNum").forEach(an => {
        const id = attr(an, "abstractNumId");
        const lvl = first(an, "lvl");
        abs[id] = lvl ? attr(first(lvl, "numFmt"), "w:val") : null;
      });
      all(d.documentElement, "num").forEach(n => {
        const numId = attr(n, "numId");
        const aid = first(n, "abstractNumId");
        const fmt = aid ? abs[attr(aid, "w:val")] : null;
        map[numId] = (fmt && /decimal|letter|roman/i.test(fmt)) ? "ol" : "ul";
      });
    } catch (e) { /* 忽略，列表默认 ul */ }
    return map;
  }

  /* ============================================================
     XLSX -> Spreadsheet cells
     ============================================================ */
  async function parseXlsx(zip) {
    console.time("[XLSX] parseXlsx 总耗时");
    console.time("[XLSX] 1. I/O 预读");
    let shared = [];
    const sf = zip.file("xl/sharedStrings.xml");
    const wbFile = zip.file("xl/workbook.xml");
    const stylesFile = zip.file("xl/styles.xml");
    const relsFile = zip.file("xl/_rels/workbook.xml.rels");
    // 预读所有 sheet*.xml
    const sheetFiles = {};
    for (const name of Object.keys(zip.files)) {
      const m = name.match(/^xl\/worksheets\/sheet(\d+)\.xml$/);
      if (m) sheetFiles[+m[1]] = zip.file(name);
    }
    if (!Object.keys(sheetFiles).length) {
      // 兜底：只有一个 sheet 的情况
      const sf2 = zip.file("xl/worksheets/sheet1.xml") || firstZip(zip, "xl/worksheets/sheet");
      if (sf2) sheetFiles[1] = sf2;
    }
    if (!Object.keys(sheetFiles).length) throw new Error("未找到工作表");

    const [sharedXml, wbXml, stylesXml, relsXml] = await Promise.all([
      sf ? sf.async("string") : Promise.resolve(null),
      wbFile ? wbFile.async("string") : Promise.resolve(null),
      stylesFile ? stylesFile.async("string") : Promise.resolve(null),
      relsFile ? relsFile.async("string") : Promise.resolve(null)
    ]);
    if (sharedXml) {
      const d = parseXML(sharedXml);
      shared = all(d.documentElement, "si").map(si => all(si, "t").map(t => t.textContent).join(""));
    }
    console.timeEnd("[XLSX] 1. I/O 预读");

    // ====== 解析 workbook.xml — sheet name 列表 + definedNames ======
    let sheetDefs = []; // [{name:"Sheet1", sheetId:1, rId:"rId1"}]
    let definedNames = []; // [{name:"myRange", formula:"Sheet1!$A$1:$C$10", localSheetId:null}]
    if (wbXml) {
      const wbD = parseXML(wbXml);
      const sheetsEl = first(wbD.documentElement, "sheets");
      if (sheetsEl) {
        const nsMap = { r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships" };
        all(sheetsEl, "sheet").forEach(s => {
          sheetDefs.push({
            name: attr(s, "name") || ("Sheet" + sheetDefs.length),
            sheetId: +(attr(s, "sheetId") || (sheetDefs.length + 1)),
            rId: attr(s, "id") || ("rId" + (sheetDefs.length + 1))
          });
        });
      }
      const dnEl = first(wbD.documentElement, "definedNames");
      if (dnEl) {
        all(dnEl, "definedName").forEach(dn => {
          definedNames.push({
            name: attr(dn, "name") || "",
            formula: (dn.textContent || "").trim(),
            localSheetId: attr(dn, "localSheetId") ? +attr(dn, "localSheetId") : null
          });
        });
      }
    }
    // 兜底：没有 workbook.xml 或 sheet 列表
    if (!sheetDefs.length) {
      Object.keys(sheetFiles).sort((a, b) => +a - +b).forEach(n => {
        sheetDefs.push({ name: "Sheet" + n, sheetId: +n, rId: "rId" + n });
      });
    }

    // ====== 解析 styles.xml ======
    const fonts = [], fills = [], borders = [], cellXfs = [], xfAlignments = [];
    const sideColor = el => { if (!el) return null; const c = first(el, "color"); const rgb = c ? attr(c, "rgb") : null; return rgb && rgb.length >= 8 ? "#" + rgb.substring(2).toLowerCase() : null; };
    if (stylesXml) {
      const sd = parseXML(stylesXml);
      all(first(sd.documentElement, "fonts") || sd.documentElement, "font").forEach(f => {
        fonts.push({
          bold: !!first(f, "b"),
          italic: !!first(f, "i"),
          underline: !!first(f, "u"),
          color: (() => { const c = first(f, "color"); if (!c) return null; const rgb = attr(c, "rgb"); return rgb && rgb.length >= 8 ? "#" + rgb.substring(2).toLowerCase() : null; })()
        });
      });
      all(first(sd.documentElement, "fills") || sd.documentElement, "fill").forEach(f => {
        const pf = first(f, "patternFill");
        fills.push({
          pattern: attr(pf, "patternType") || "none",
          fg: (() => { if (!pf) return null; const c = first(pf, "fgColor"); if (!c) return null; const rgb = attr(c, "rgb"); return rgb && rgb.length >= 8 ? "#" + rgb.substring(2).toLowerCase() : null; })()
        });
      });
      // borders: <border><left style="thin"><color rgb="FF000000"/></left>...</border>
      all(first(sd.documentElement, "borders") || sd.documentElement, "border").forEach(b => {
        const bd = {};
        ["left", "right", "top", "bottom"].forEach(side => {
          const el = first(b, side);
          const st = el ? attr(el, "style") : null;
          if (st) bd[side] = { style: st, color: sideColor(el) };
        });
        borders.push(bd);
      });
      all(first(sd.documentElement, "cellXfs") || sd.documentElement, "xf").forEach(xf => {
        cellXfs.push({
          fontId: +(attr(xf, "fontId") || 0),
          fillId: +(attr(xf, "fillId") || 0),
          borderId: +(attr(xf, "borderId") || 0),
          applyFont: attr(xf, "applyFont") === "1",
          applyFill: attr(xf, "applyFill") === "1",
          applyBorder: attr(xf, "applyBorder") === "1",
          applyAlignment: attr(xf, "applyAlignment") === "1"
        });
        // 解析 applyAlignment 内联 <alignment> 子元素 — 存局部数组，后面赋 styles._alignments
        const alignEl = first(xf, "alignment");
        if (alignEl) {
          xfAlignments.push({
            horizontal: attr(alignEl, "horizontal") || "",
            vertical: attr(alignEl, "vertical") || "",
            wrapText: attr(alignEl, "wrapText") === "1",
            indent: +(attr(alignEl, "indent") || "0")
          });
        } else {
          xfAlignments.push(null);
        }
      });
    }

    // ====== 单 sheet 解析函数（内部 async，共享外层 styles/fonts/...）======
    async function _parseOneSheet(sheetXml, sheetIdx, relsMap) {
    relsMap = relsMap || {};
    const d = parseXML(sheetXml);
    const cells = {};
    const styles = {};
    styles._alignments = xfAlignments; // styles.xml 里每个 xf 的 <alignment> 子元素
    const merges = [];
    const _hyperlinks = []; // 超链接临时收集（内联 + hyperlinks 区域）
    // cells 遍历时检测 <hyperlink r:id="rId1"/> 子元素
    const hyperlinkChild = (cEl) => {
      for (const child of (cEl.children || [])) {
        if (child.localName === "hyperlink") {
          const rid = attr(child, "id");
          const loc = attr(child, "location") || attr(child, "ref");
          if (rid && relsMap[rid]) _hyperlinks.push({ ref, target: relsMap[rid], display: "" });
          else if (loc) _hyperlinks.push({ ref, target: loc, display: "" });
          return true;
        }
      }
      return false;
    };
    console.time("[XLSX] 2. 单元格遍历");
    let maxC = 1, maxR = 1;
    all(d.documentElement, "c").forEach(c => {
      const ref = attr(c, "r"); if (!ref) return;
      const t = attr(c, "t");
      const sIdx = attr(c, "s");
      const f = first(c, "f");
      const v = first(c, "v");
      const is = first(c, "is");
      const { c: ci, r: ri } = refToRC(ref);
      maxC = Math.max(maxC, ci); maxR = Math.max(maxR, ri);
      if (f) {
        const cell = { f: "=" + (f.textContent || "").trim() };
        // 同时保存 v（Excel 缓存值），FE.run 失败时回退显示
        if (v) {
          let val;
          if (t === "s") val = shared[+v.textContent] || "";
          else if (t === "str") val = v.textContent;
          else if (t === "b") val = v.textContent === "1" ? "TRUE" : "FALSE";
          else val = v.textContent;
          cell.v = isNum(val) ? Number(val) : val;
        }
        cells[ref] = cell;
      } else {
        let val;
        if (t === "s") val = shared[+v.textContent] || "";
        else if (t === "inlineStr") val = is ? all(is, "t").map(x => x.textContent).join("") : "";
        else if (t === "str") val = v ? v.textContent : "";
        else if (t === "b") val = v && v.textContent === "1" ? "TRUE" : "FALSE";
        else val = v ? v.textContent : "";
        cells[ref] = { v: isNum(val) ? Number(val) : val };
      }
      if (sIdx && cellXfs.length) {
        const xf = cellXfs[+sIdx];
        if (xf) {
          const st = {};
          if (xf.applyFont) {
            const font = fonts[xf.fontId] || {};
            if (font.bold) st.bold = true;
            if (font.italic) st.italic = true;
            if (font.underline) st.underline = true;
            if (font.color) st.color = font.color;
          }
          if (xf.applyFill) {
            const fill = fills[xf.fillId] || {};
            if (fill.pattern === "solid" && fill.fg) st.bg = fill.fg;
          }
          if (xf.applyBorder) {
            const bd = borders[xf.borderId] || {};
            const sides = {};
            ["left", "right", "top", "bottom"].forEach(side => { if (bd[side]) sides[side] = bd[side]; });
            if (Object.keys(sides).length) st.border = sides;
          }
          if (Object.keys(st).length) styles[ref] = st;
        }
      }
      // 内联 hyperlink 子元素
      hyperlinkChild(c);
    });

    // hyperlinks 区域（独立 <hyperlinks><hyperlink ref="A1" r:id="rId1"/></hyperlinks>）
    const hlsEl = first(d.documentElement, "hyperlinks");
    if (hlsEl) {
      all(hlsEl, "hyperlink").forEach(hl => {
        const hlRef = (attr(hl, "ref") || "").trim().toUpperCase();
        const rid = attr(hl, "id");
        const loc = attr(hl, "location");
        let target = "";
        if (rid && relsMap[rid]) target = relsMap[rid];
        else if (loc) target = loc;
        if (hlRef && target) _hyperlinks.push({ ref: hlRef, target, display: "" });
      });
    }

    // mergeCells: <mergeCell ref="A1:B2"/>
    const mergeCellsEl = first(d.documentElement, "mergeCells");
    if (mergeCellsEl) all(mergeCellsEl, "mergeCell").forEach(m => { const ref = attr(m, "ref"); if (ref && ref.includes(":")) merges.push({ range: ref, type: "merge" }); });

    // ---------- 数据验证导入 <dataValidation> ----------
    const DV_TYPE_MAP = { whole: "whole", integer: "whole", decimal: "decimal", list: "list", date: "date", time: "time", textLength: "textLength", custom: "custom", formula: "custom" };
    const DV_OP_MAP = { between: "between", notBetween: "notBetween", equal: "equal", notEqual: "notEqual", greaterThan: "greaterThan", lessThan: "lessThan", greaterThanOrEqual: "greaterThanOrEqual", lessThanOrEqual: "lessThanOrEqual" };
    const validations = [];
    const dvListEl = first(d.documentElement, "dataValidations");
    if (dvListEl) {
      all(dvListEl, "dataValidation").forEach(dv => {
        const typeRaw = attr(dv, "type") || "list";
        const opRaw = attr(dv, "operator") || "between";
        const dvType = DV_TYPE_MAP[typeRaw] || "list";
        const op = DV_OP_MAP[opRaw] || "between";
        const sqref = (attr(dv, "sqref") || attr(dv, "ref") || "").trim().toUpperCase();
        if (!sqref) return;
        const allowBlank = attr(dv, "allowBlank") !== "0";
        const showDropDown = attr(dv, "showDropDown") !== "0";
        const form1 = first(dv, "formula1");
        const form2 = first(dv, "formula2");
        let formula1 = form1 ? (form1.textContent || "").trim() : null;
        let formula2 = form2 ? (form2.textContent || "").trim() : null;
        let listItems = null;
        if (dvType === "list") {
          let raw = formula1 || "";
          if (raw.startsWith('"') && raw.endsWith('"')) raw = raw.slice(1, -1);
          listItems = raw.split(",").map(s => s.trim()).filter(Boolean);
          if (!listItems.length) listItems = null;
        } else if (formula1 === "") formula1 = null;
        if (formula2 === "") formula2 = null;
        let errorAlert = { show: false, style: "stop", title: "", message: "" };
        let inputMessage = { show: false, title: "", message: "" };
        all(dv, "errorAlert").forEach(ea => {
          errorAlert = {
            show: attr(ea, "show") !== "0",
            style: attr(ea, "errorStyle") || "stop",
            title: attr(ea, "title") || "",
            message: attr(ea, "errorMessage") || ""
          };
        });
        all(dv, "inputMessage").forEach(im => {
          inputMessage = {
            show: attr(im, "show") !== "0",
            title: attr(im, "title") || "",
            message: attr(im, "prompt") || ""
          };
        });
        validations.push({
          range: sqref, type: dvType, operator: op,
          formula1: formula1, formula2: formula2, list: listItems,
          allowBlank: allowBlank, showDropDown: showDropDown,
          errorAlert: errorAlert, inputMessage: inputMessage
        });
      });
    }
    // ---------- 条件格式导入 <conditionalFormatting> ----------
    const condFormats = [];

    // ---------- 冻结窗格 + 工作表级属性 ----------
    let freeze = { row: 0, col: 0 };
    let tabColor = "";
    let defaultRowHeight = 18;
    let customRowHeights = {}; // rowIdx → height
    const svListEl = first(d.documentElement, "sheetViews");
    if (svListEl) {
      const sv = first(svListEl, "sheetView");
      if (sv) {
        const pane = first(sv, "pane");
        if (pane) {
          freeze.col = +(attr(pane, "xSplit") || "0");
          freeze.row = +(attr(pane, "ySplit") || "0");
        }
      }
    }
    const tabColorEl = first(d.documentElement, "sheetPr");
    if (tabColorEl) {
      const tc = first(tabColorEl, "tabColor");
      if (tc) tabColor = attr(tc, "rgb") || attr(tc, "theme") || "";
    }
    // sheetProtection 保护工作表
    let protection = null;
    const spEl = first(d.documentElement, "sheetProtection");
    if (spEl) {
      protection = {
        enabled: attr(spEl, "sheet") !== "0",
        password: attr(spEl, "password") || "",
        sheet: attr(spEl, "sheet") !== "0",
        objects: attr(spEl, "objects") !== "0",
        scenarios: attr(spEl, "scenarios") !== "0",
        formatCells: attr(spEl, "formatCells") !== "0",
        formatColumns: attr(spEl, "formatColumns") !== "0",
        formatRows: attr(spEl, "formatRows") !== "0",
        insertColumns: attr(spEl, "insertColumns") !== "0",
        insertRows: attr(spEl, "insertRows") !== "0",
        deleteColumns: attr(spEl, "deleteColumns") !== "0",
        deleteRows: attr(spEl, "deleteRows") !== "0"
      };
    }
    // autoFilter 筛选器
    let filters = [];
    const afEl = first(d.documentElement, "autoFilter");
    if (afEl) {
      filters.push({ range: (attr(afEl, "ref") || "").trim().toUpperCase() });
    }
    const sdpEl = first(d.documentElement, "sheetFormatPr");
    if (sdpEl) defaultRowHeight = +(attr(sdpEl, "defaultRowHeight") || "18");
    // 自定义行高（<row customHeight="1" h="24"/>）
    const rowsEl = first(d.documentElement, "sheetData");
    if (rowsEl) {
      all(rowsEl, "row").forEach(r => {
        const customH = attr(r, "customHeight");
        const h = attr(r, "ht");
        if (customH === "1" && h) customRowHeights[+(attr(r, "r") || "0")] = +h;
      });
    }
    // 自定义列宽 <cols><col min= max= width= customWidth=/>
    const colsEl = first(d.documentElement, "cols");
    const colWidths = [];
    if (colsEl) {
      all(colsEl, "col").forEach(c => {
        const minC = +(attr(c, "min") || "0");
        const maxC = +(attr(c, "max") || "0");
        const w = +(attr(c, "width") || "0");
        if (minC > 0 && maxC >= minC && w > 0) {
          for (let ci = minC; ci <= maxC; ci++) colWidths[ci] = w;
        }
      });
    }

    const cfListEl = first(d.documentElement, "conditionalFormatting");
    if (cfListEl) {
      // OOXML 标准 op → 内部 op
      const CF_OP_MAP = { "between": "between", "notBetween": "between", "equal": "eq", "notEqual": "ne", "greaterThan": "gt", "lessThan": "lt", "greaterThanOrEqual": "ge", "lessThanOrEqual": "le", "containsText": "contains" };
      // OOXML type → 内部 type
      const CF_TYPE_MAP = { "expression": "cell", "cellIs": "cell", "colorScale": "scale", "dataBar": "bar", "iconSet": "icon", "top10": "top" };
      // OOXML operator → 内部 op（条件格式专用）
      all(cfListEl, "cfRule").forEach(cf => {
        const cfType = attr(cf, "type") || "expression";
        const priority = +(attr(cf, "priority") || "0");
        const opRaw = attr(cf, "operator") || "between";
        const op = CF_OP_MAP[opRaw] || "between";
        const internalType = CF_TYPE_MAP[cfType] || "cell";
        let formula1 = "", formula2 = "";
        const f1El = first(cf, "formula1"); if (f1El) formula1 = (f1El.textContent || "").trim();
        const f2El = first(cf, "formula2"); if (f2El) formula2 = (f2El.textContent || "").trim();
        let color1 = "", color2 = "", color3 = "";
        // dxf 样式 → 取填充色
        const dxf = first(cf, "dxf");
        if (dxf) {
          const fill = first(dxf, "fill");
          const pattFill = fill ? first(fill, "patternFill") : null;
          const fgColor = pattFill ? first(pattFill, "fgColor") : null;
          if (fgColor) color1 = attr(fgColor, "rgb") || attr(fgColor, "theme") || "";
        }
        // colorScale 专用
        const cs = first(cf, "colorScale");
        if (cs) {
          const colors = all(cs, "color").map(c => attr(c, "rgb") || attr(c, "theme") || "");
          const vals = all(cs, "cfvo").map(v => +(attr(v, "val") || "0"));
          color1 = colors[0] || ""; color2 = colors[1] || ""; color3 = colors[2] || "";
        }
        // dataBar 专用
        const db = first(cf, "dataBar");
        let barColor = "", negColor = "";
        if (db) {
          const colEl = first(db, "color"); if (colEl) barColor = attr(colEl, "rgb") || attr(colEl, "theme") || "";
          const negBarColorEl = first(db, "negativeFillColor") || first(db, "negativeColor");
          if (negBarColorEl) negColor = attr(negBarColorEl, "rgb") || attr(negBarColorEl, "theme") || "";
        }
        const rule = {
          id: "cf" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          range: (attr(cfListEl, "sqref") || "").trim().toUpperCase(),
          type: internalType,
          priority: priority,
          op: op, v: formula1, v2: formula2,
          bg: color1, color: color1,
          minColor: color1 || "#63be7b", midColor: color2 || "", maxColor: color3 || "#f8696b",
          color: barColor || "#638ec4", negColor: negColor || "#f8696b"
        };
        condFormats.push(rule);
      });
    }
      // 函数返回单 sheet 对象
      return { name: "Sheet" + (sheetIdx + 1), rows: Math.max(maxR, 50), cols: Math.max(maxC, 16), cells, styles, merge: merges, charts: [], validations, condFormats, freeze, tabColor, defaultRowHeight, customRowHeights, colWidths, protection, filters, hyperlinks: _hyperlinks };
    } // _parseOneSheet 结束

    // ====== 循环解析所有 sheet（Promise.all 预读 xml + rels + 逐 sheet 调 _parseOneSheet）======
    const sheetNumbers = Object.keys(sheetFiles).sort((a,b)=>+a-+b).map(n=>+n);
    const allSheetXmls = await Promise.all(sheetNumbers.map(n => sheetFiles[n].async("string")));
    // 预读每个 sheet 的 rels 文件 → relsMaps[idx] = { rId1: "https://...", rId2: "Sheet2!A1", ... }
    const relsMaps = [];
    for (const n of sheetNumbers) {
      const relsFile = zip.file("xl/worksheets/_rels/sheet" + n + ".xml.rels");
      if (relsFile) {
        try {
          const relsD = parseXML(await relsFile.async("string"));
          const m = {};
          all(first(relsD.documentElement, "Relationships") || relsD.documentElement, "Relationship").forEach(r => {
            m[attr(r, "Id")] = attr(r, "Target") || "";
          });
          relsMaps.push(m);
        } catch(e) { relsMaps.push({}); }
      } else relsMaps.push({});
    }
    const sheets = [];
    const safeRels = (idx) => relsMaps[idx] || {};
    for (let i = 0; i < sheetDefs.length && i < allSheetXmls.length; i++) {
      const sheet = await _parseOneSheet(allSheetXmls[i], i, safeRels(i));
      sheet.name = sheetDefs[i].name;
      sheets.push(sheet);
    }
    for (let i = sheetDefs.length; i < allSheetXmls.length; i++) {
      const sheet = await _parseOneSheet(allSheetXmls[i], i, safeRels(i));
      sheet.name = "Sheet" + (sheetNumbers[i] || i + 1);
      sheets.push(sheet);
    }
    const hasFmt = sheets.some(s => Object.keys(s.styles).length);
    const hasMerge = sheets.some(s => s.merge && s.merge.length);
    const noteExtra = [hasFmt ? "格式已保留" : null, hasMerge ? "合并单元格已保留" : null].filter(Boolean).join("；");
    const note = sheets.length
      ? `XLSX 已导入（多表：${sheets.length} 个工作表${noteExtra ? "；" + noteExtra : ""}）`
      : "XLSX 已导入（空表）";

    // ---------- 批注导入（xl/comments/commentN.xml，逐 sheet）----------
    const comments = [];
    // 收集所有 comment*.xml 并按序号排序
    const commentFiles = {};
    Object.keys(zip.files).forEach(f => {
      const m = f.match(/^xl\/comments\/comment(\d+)\.xml$/);
      if (m) commentFiles[+m[1]] = zip.file(f);
    });
    // comment1.xml 特殊兜底
    if (!commentFiles[1]) { const f = zip.file("xl/comments/comment1.xml"); if (f) commentFiles[1] = f; }
    for (const [nStr, cmtFile] of Object.entries(commentFiles)) {
      const sheetIdx = +nStr - 1;  // comment1 -> sheet 0, comment2 -> sheet 1
      if (!cmtFile) continue;
      try {
        const cd = parseXML(await cmtFile.async("string"));
        const authorNames = [];
        const authorsEl = first(cd.documentElement, "authors");
        if (authorsEl) {
          all(authorsEl, "author").forEach(a => authorNames.push((a.textContent || "").trim() || "作者"));
        }
        all(cd.documentElement, "comment").forEach(cc => {
          const ref = attr(cc, "ref") || "";
          if (!ref) return;
          const authorId = +(attr(cc, "authorId") || "0");
          const textEl = first(cc, "text");
          const text = textEl ? all(textEl, "t").map(t => t.textContent || "").join("") : "";
          const cid = "cmt" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
          comments.push({
            id: cid, ref: ref, sheet: sheetIdx,
            author: authorNames[authorId] || "作者",
            createdAt: Date.now(), resolved: false,
            text: text || "",
            replies: []
          });
        });
      } catch (e) { /* 批注解析失败不阻断导入 */ }
    }

    console.timeEnd("[XLSX] 2. 单元格遍历");
    console.timeEnd("[XLSX] parseXlsx 总耗时");
    // 向后兼容：单表时同时暴露老单表结构（data.cells/styles/merge 等）
    const compatFlat = sheets.length === 1 ? {
      rows: sheets[0].rows, cols: sheets[0].cols,
      cells: sheets[0].cells, styles: sheets[0].styles, merge: sheets[0].merge,
      charts: sheets[0].charts, condFormats: sheets[0].condFormats,
      validations: sheets[0].validations, filters: sheets[0].filters,
      freeze: sheets[0].freeze, tabColor: sheets[0].tabColor,
      defaultRowHeight: sheets[0].defaultRowHeight,
      customRowHeights: sheets[0].customRowHeights,
      colWidths: sheets[0].colWidths, protection: sheets[0].protection
    } : {};
    return {
      type: "spreadsheet",
      data: Object.assign({}, {
        sheets, definedNames, comments,
        compat: hasFmt ? "A" : "B", note
      }, compatFlat),
      compat: hasFmt ? "A" : "B",
      note
    };
  }

  /* ============================================================
     PPTX -> Presentation slides
     ============================================================ */
  async function parsePptx(zip) {
    console.time("[PPTX] parsePptx 总耗时");
    // 安全取 zip 条目 — 大文件/特殊格式下 zip.file() 可能返回 null
    const safeFile = (name) => zip.file(name);
    // 幻灯片尺寸（EMU → 像素）
    let sldW = 12192000, sldH = 6858000;
    let sldSzOrient = "land";
    const pres = zip.file("ppt/presentation.xml");
    if (pres) {
      const pd = parseXML(await pres.async("string"));
      const sz = first(pd.documentElement, "sldSz");
      if (sz) { sldW = +attr(sz, "cx") || sldW; sldH = +attr(sz, "cy") || sldH; }
      sldSzOrient = (attr(sz, "orient") || "land");
    }
    const isPort = sldSzOrient === "port";
    // 渲染画布尺寸（保持 16:9 比例不变形）
    const refW = isPort ? 427 : 760;
    const refH = isPort ? 760 : 427;
    const W = refW, H = refH;
    const fx = W / sldW, fy = H / sldH;

    // ========== 1. 预读所有 slide rels + 预取 ppt/media 图片转 data URI ==========
    console.time("[PPTX] 1. media + rels 预读");
    const mediaMap = {};   // rId -> { path, dataUrl }
    const allRels = {};    // slidePath -> { rId -> target }
    const mediaFiles = Object.keys(zip.files).filter(n => /^ppt\/media\//.test(n));
    // 预读 media 文件
    await Promise.all(mediaFiles.map(async mp => {
      const f = zip.file(mp);
      if (!f) return;
      const u8 = await f.async("uint8array");
      let mime = "image/png";
      if (/\.(jpe?g|jpe)$/.test(mp)) mime = "image/jpeg";
      else if (/\.gif$/.test(mp)) mime = "image/gif";
      else if (/\.bmp$/.test(mp)) mime = "image/bmp";
      else if (/\.svg$/.test(mp)) mime = "image/svg+xml";
      else if (/\.webp$/.test(mp)) mime = "image/webp";
      else if (/\.mp3$/.test(mp)) mime = "audio/mpeg";
      else if (/\.mp4$/.test(mp)) mime = "video/mp4";
      // base64 编码（chunk 分割避免 O(N²) 字符串拼接）
      try {
        let bin = "";
        const CHUNK = 8192;
        for (let i = 0; i < u8.length; i += CHUNK) {
          bin += String.fromCharCode.apply(null, u8.subarray(i, Math.min(i + CHUNK, u8.length)));
        }
        mediaMap[mp] = "data:" + mime + ";base64," + btoa(bin);
      } catch (e) { mediaMap[mp] = ""; }
    }));

    // 预读所有 rels + 预解析 layout 背景（全部并行）
    const slideRels = Object.keys(zip.files).filter(n => /^ppt\/slides\/_rels\/slide\d+\.xml\.rels$/.test(n)).sort();
    const layoutRels = Object.keys(zip.files).filter(n => /^ppt\/slideLayouts\/_rels\/slideLayout\d+\.xml\.rels$/.test(n)).sort();
    const masterRels = Object.keys(zip.files).filter(n => /^ppt\/slideMasters\/_rels\/slideMaster\d+\.xml\.rels$/.test(n)).sort();
    const layoutFiles = Object.keys(zip.files).filter(n => /^ppt\/slideLayouts\/slideLayout\d+\.xml$/.test(n)).sort((a, b) => (+/slideLayout(\d+)/.exec(a)[1]) - (+/slideLayout(\d+)/.exec(b)[1]));

    await Promise.all([
      // slide rels
      ...slideRels.map(async rp => {
        const relF = zip.file(rp);
        if (!relF) return;
        const relXml = await relF.async("string");
        const slideName = rp.replace("ppt/slides/_rels/", "").replace(".rels", "");
        allRels[slideName] = parseRels(relXml);
      }),
      // slideLayout rels
      ...layoutRels.map(async rp => {
        const relF = zip.file(rp);
        if (!relF) return;
        const relXml = await relF.async("string");
        const key = rp.replace("ppt/slideLayouts/_rels/", "").replace(".rels", "");
        allRels[key] = parseRels(relXml);
      }),
      // slideMaster rels
      ...masterRels.map(async rp => {
        const relF = zip.file(rp);
        if (!relF) return;
        const relXml = await relF.async("string");
        const key = rp.replace("ppt/slideMasters/_rels/", "").replace(".rels", "");
        allRels[key] = parseRels(relXml);
      }),
      // layout 背景预解析
      ...layoutFiles.map(async lf => {
        try {
          const lxd = parseXML(await zip.file(lf).async("string"));
          const lbg = first(lxd.documentElement, "bg");
          const layoutName = lf.split("/").pop();
          const c = extractBgFillColor(lbg, allRels[layoutName], "ppt/slideLayouts/");
          // 写回 allRels 旁路：用 _bg_ 前缀存布局背景
          if (!allRels._layoutBg) allRels._layoutBg = {};
          allRels._layoutBg[layoutName] = c || null;
        } catch (_) {}
      })
    ]);
    const layoutBgMap = allRels._layoutBg || {};
    console.timeEnd("[PPTX] 1. media + rels 预读");

    // ========== 2. 读 slideMaster 的背景（用于继承回退） ==========
    let masterBg = "#ffffff";
    const sm = zip.file("ppt/slideMasters/slideMaster1.xml");
    if (sm) {
      const smd = parseXML(await sm.async("string"));
      const mbg = first(smd.documentElement, "bg");
      const c = extractBgFillColor(mbg, allRels["slideMaster1.xml"], "ppt/slideMasters/");
      if (c) masterBg = c;
    }

    // ========== 3. 遍历每张 slide ==========
    const slideEntries = Object.keys(zip.files)
      .filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n))
      .sort((a, b) => (+/slide(\d+)/.exec(a)[1]) - (+/slide(\d+)/.exec(b)[1]));

    // 工具：从 rId 找 media base64（baseDir 决定相对路径解析根目录：slides / slideLayouts / slideMasters）
    function resolveMediaByRels(rels, rId, baseDir) {
      if (!rels || !rId) return null;
      const target = rels[rId];
      if (!target) return null;
      baseDir = baseDir || "ppt/slides/";
      // target 相对 baseDir：../media/image1.png -> ppt/media/image1.png
      let path = baseDir + target;
      // 折叠 "xxx/../" → "" （例："ppt/slides/../media/image.png" -> "ppt/media/image.png"）
      // 用循环处理多层嵌套（a/b/../../c → c）
      while (path.indexOf("/../") !== -1) {
        path = path.replace(/[^/]+\/\.\.\//, "");
      }
      const dataUrl = mediaMap[path];
      return dataUrl || null;
    }

    // 工具：从 <a:srgbClr> / <a:schemeClr> / <a:scrgbClr> 提取颜色
    function extractFillColor(fillNode) {
      if (!fillNode) return null;
      const srgb = first(fillNode, "srgbClr");
      if (srgb) return "#" + attr(srgb, "val");
      const scheme = first(fillNode, "schemeClr");
      if (scheme) {
        // 主题色：返回默认映射（简化处理）
        const map = {
          "bg1": "#ffffff", "tx1": "#000000",
          "bg2": "#f0f0f0", "tx2": "#333333",
          "accent1": "#4472c4", "accent2": "#ed7d31",
          "accent3": "#a5a5a5", "accent4": "#ffc000",
          "accent5": "#5b9bd5", "accent6": "#70ad47"
        };
        return map[attr(scheme, "val")] || "#888888";
      }
      return null;
    }

    // 工具：从 <p:bg> / <p:bgPr> 节点提取背景值（颜色字符串 或 "url(data:图片base64)"）
    // PPTX 背景结构：<p:bg><p:bgPr>{solidFill|gradFill|blipFill|noFill}</p:bgPr></p:bg>
    // 或引用：<p:bg><p:bgRef idx="N"><a:schemeClr val="xxx"/></p:bgRef></p:bg>
    // blipFill 需要 rels + baseDir 从 rId 找 media 图片
    function extractBgFillColor(bgNode, rels, baseDir) {
      if (!bgNode) return null;
      // 路径1：bgPr 直接填充（solidFill / gradFill / blipFill / noFill）
      const bgPr = first(bgNode, "bgPr");
      const fillHost = bgPr || bgNode;
      // solidFill
      const solid = first(fillHost, "solidFill");
      if (solid) { const c = extractFillColor(solid); if (c) return c; }
      // gradFill 渐变 → 取第一个 stop 的颜色
      const grad = first(fillHost, "gradFill");
      if (grad) {
        const gsLst = first(grad, "gsLst");
        if (gsLst && gsLst.children && gsLst.children.length) {
          const firstGs = gsLst.children[0];
          const c = extractFillColor(firstGs);
          if (c) return c;
        }
      }
      // blipFill 图片背景 → 从 rels 找 rId → mediaMap 拿 data URL
      const blipFill = first(fillHost, "blipFill");
      if (blipFill && rels) {
        const blip = first(blipFill, "blip");
        if (blip) {
          const rId = attr(blip, "embed"); // attr() 自动处理 r:embed 命名空间
          const dataUrl = resolveMediaByRels(rels, rId, baseDir);
          if (dataUrl) return "url(" + dataUrl + ")";
        }
      }
      // bgRef 引用（idx 指向 theme/slideLayout，简化处理：直接在里面找颜色）
      const bgRef = first(bgNode, "bgRef");
      if (bgRef) {
        const c = extractFillColor(bgRef);
        if (c) return c;
      }
      // 兜底：深度搜 srgbClr / schemeClr
      const srgb = first(bgNode, "srgbClr");
      if (srgb) return "#" + attr(srgb, "val");
      const scheme = first(bgNode, "schemeClr");
      if (scheme) return extractFillColor(scheme.parentElement || bgNode);
      return null;
    }

    // 工具：从 spPr 读取 shape 属性（shape type / fill / stroke / radius）
    function parseSpPr(spPr, parentXfrm) {
      const result = { shape: "rect", fill: null, stroke: null, strokeWidth: 0, radius: 0 };
      if (!spPr) return result;
      // 形状类型
      const geom = first(spPr, "prstGeom");
      if (geom) {
        const prst = attr(geom, "prst") || "rect";
        const shapeMap = {
          "rect": "rect", "roundRect": "rect", "ellipse": "ellipse",
          "line": "arrow", "chevron": "rect", "downArrow": "arrow", "upArrow": "arrow",
          "leftArrow": "arrow", "rightArrow": "arrow", "pentagon": "rect",
          "hexagon": "rect", "parallelogram": "rect", "trapezoid": "rect"
        };
        result.shape = shapeMap[prst] || "rect";
        // 圆角矩形的 adjust 值影响圆角半径（简化处理）
      }
      // 填充
      const solidFill = first(spPr, "solidFill");
      if (solidFill) result.fill = extractFillColor(solidFill);
      // 描边
      const ln = first(spPr, "ln");
      if (ln) {
        const lnFill = first(ln, "solidFill");
        result.stroke = extractFillColor(lnFill);
        const w = attr(ln, "w");
        if (w) result.strokeWidth = Math.round((+w) / 12700); // EMU -> pt -> px
      }
      return result;
    }

    // 工具：递归遍历 spTree 子元素，生成 elements 数组
    function walkSpTree(parent, rels, offX, offY, slideWEMU, slideHEMU) {
      const result = [];
      const kids = parent ? parent.children : [];
      for (let i = 0; i < kids.length; i++) {
        const k = kids[i];
        const ln = k.localName;
        if (ln === "sp") {
          const text = shapeText(k);
          const xfrm = first(k, "xfrm");
          const off = xfrm ? first(xfrm, "off") : null;
          const ext = xfrm ? first(xfrm, "ext") : null;
          // 跳过 background shape：覆盖整个 slide + 空文本
          if (off && ext && slideWEMU && slideHEMU) {
            const ox = +attr(off, "x"), oy = +attr(off, "y");
            const cx = +attr(ext, "cx"), cy = +attr(ext, "cy");
            if (ox === 0 && oy === 0 && cx === slideWEMU && cy === slideHEMU && !text) continue;
          }
          const x = off ? Math.round((+attr(off, "x") + offX) * fx) : 40;
          const y = off ? Math.round((+attr(off, "y") + offY) * fy) : 40;
          const w = ext ? Math.max(4, Math.round((+attr(ext, "cx")) * fx)) : 200;
          const h = ext ? Math.max(4, Math.round((+attr(ext, "cy")) * fy)) : 40;
          const { fontSize, color, bold, italic, fontFamily, align } = runStyle(k, fx);
          const spPr = first(k, "spPr");
          const geom = parseSpPr(spPr);
          if (text) {
            result.push({
              id: OS.util.uid("el"), type: "text", x, y, w, h,
              text, fontSize: fontSize || 14, color: color || "#111827", bold: !!bold,
              italic: !!italic, fontFamily, align,
              shape: geom.shape, fill: geom.fill, stroke: geom.stroke, strokeWidth: geom.strokeWidth
            });
          } else if (geom.fill || geom.stroke) {
            // 空文本但有填充色 → 是形状（如矩形、圆），也当 shape 输出
            result.push({
              id: OS.util.uid("el"), type: "shape", x, y, w, h,
              shape: geom.shape, fill: geom.fill || "#e0e7ff",
              stroke: geom.stroke, strokeWidth: geom.strokeWidth,
              text: "", fontSize: fontSize || 14, color: color || "#111827", bold: !!bold,
              italic: !!italic, fontFamily, align
            });
          }
        } else if (ln === "pic") {
          // 图片
          const nvPicPr = first(k, "nvPicPr");
          const xfrm = nvPicPr ? first(nvPicPr, "xfrm") : null;
          // 也可能在 blipFill 里
          let offExt = first(k, "xfrm");
          if (!offExt) offExt = nvPicPr ? first(nvPicPr, "xfrm") : null;
          const off = offExt ? first(offExt, "off") : null;
          const ext = offExt ? first(offExt, "ext") : null;
          const x = off ? Math.round((+attr(off, "x") + offX) * fx) : 40;
          const y = off ? Math.round((+attr(off, "y") + offY) * fy) : 40;
          const w = ext ? Math.max(4, Math.round((+attr(ext, "cx")) * fx)) : 200;
          const h = ext ? Math.max(4, Math.round((+attr(ext, "cy")) * fy)) : 100;
          const blip = first(k, "blip");
          const rId = blip ? attr(blip, "embed") : null;
          const dataUrl = resolveMediaByRels(rels, rId);
          if (dataUrl) {
            result.push({ id: OS.util.uid("el"), type: "image", x, y, w, h, src: dataUrl });
          }
        } else if (ln === "grpSp") {
          // 组合形状：递归遍历内部
          const grpSpPr = first(k, "grpSpPr");
          const xfrm = grpSpPr ? first(grpSpPr, "xfrm") : null;
          const off = xfrm ? first(xfrm, "off") : null;
          const gx = off ? (+attr(off, "x")) : 0;
          const gy = off ? (+attr(off, "y")) : 0;
          result.push(...walkSpTree(k, rels, offX + gx, offY + gy, slideWEMU, slideHEMU));
        } else if (ln === "cxnSp") {
          // 连接线 → arrow
          const xfrm = first(k, "xfrm");
          const off = xfrm ? first(xfrm, "off") : null;
          const ext = xfrm ? first(xfrm, "ext") : null;
          const x = off ? Math.round((+attr(off, "x") + offX) * fx) : 40;
          const y = off ? Math.round((+attr(off, "y") + offY) * fy) : 40;
          const w = ext ? Math.max(4, Math.round((+attr(ext, "cx")) * fx)) : 100;
          const h = ext ? Math.max(4, Math.round((+attr(ext, "cy")) * fy)) : 4;
          const spPr = first(k, "spPr");
          const geom = parseSpPr(spPr);
          result.push({
            id: OS.util.uid("el"), type: "shape", shape: "arrow",
            x, y, w, h, fill: "transparent",
            stroke: geom.stroke || "#111827", strokeWidth: geom.strokeWidth || 1,
            text: "", fontSize: 14, color:OS.theme.getVar("undefined"), bold: false
          });
        }
        // nvGrpSpPr / grpSpPr 等 prst 属性直接忽略
      }
      return result;
    }

    // ========== 4. 遍历每张 slide ==========
    const slides = [];
    for (const name of slideEntries) {
      const sd = parseXML(await zip.file(name).async("string"));
      const sld = first(sd.documentElement, "sld") || sd.documentElement;

      // 取 slide 自己的 rels（提前，背景 fallback 链路需要）
      const relsKey = name.replace("ppt/slides/", ""); // slide1.xml
      const rels = allRels[relsKey] || {};

      // 背景继承链：slide 自己的 bg → slideLayout bg → slideMaster bg → 默认白
      let bgColor = masterBg;
      const bgNode = first(sld, "bg");
      const slideOwnBg = extractBgFillColor(bgNode, rels, "ppt/slides/");
      if (slideOwnBg) {
        bgColor = slideOwnBg; // slide 自己设了 → 最高优先级
      } else {
        // fallback：从 rels 找 slideLayout → 查预解析的 layoutBgMap
        let layoutBg = null;
        for (const target of Object.values(rels)) {
          const m = target.match(/slideLayouts\/(slideLayout\d+\.xml)/);
          if (m) { layoutBg = layoutBgMap[m[1]]; break; }
        }
        if (layoutBg) bgColor = layoutBg;
      }
      console.log("[PPTX-BG]", name, "slideBg?", !!bgNode, "slideBgExtracted:", slideOwnBg || "null", "layoutBg:", (() => { for (const t of Object.values(rels)) { const m=t.match(/slideLayouts\/(slideLayout\d+\.xml)/); if(m) return layoutBgMap[m[1]] || "null"; } return "no-layout-rel"; })(), "master:", masterBg, "→ final:", bgColor);

      // spTree（注意：PPTX 里 spTree 可能多层嵌套 <p:spTree><a:spTree>，需要取最深一层）
      let cSld = first(sld, "cSld");
      let spTree = cSld ? first(cSld, "spTree") : null;
      // 继续往里钻直到不再有 spTree
      while (spTree && first(spTree, "spTree")) {
        spTree = first(spTree, "spTree");
      }
      let elements = [];
      if (spTree) {
        elements = walkSpTree(spTree, rels, 0, 0, sldW, sldH);
      }
      // 过滤：跳过完全超出 slide 边界的元素（动画初始 off-screen 位置 / 布局溢出）
      // 有 50px 容差（允许部分超出但保留可见部分）
      const offScreenTol = 50;
      elements = elements.filter(el =>
        el.x + el.w > -offScreenTol &&
        el.y + el.h > -offScreenTol &&
        el.x < (W + offScreenTol) &&
        el.y < (H + offScreenTol)
      );

      // 演讲者备注（保留原逻辑）
      let notes = "";
      const relName = name.replace(/ppt\/slides\/(slide\d+\.xml)$/, "ppt/slides/_rels/$1.rels");
      const relFile = zip.file(relName);
      if (relFile) {
        const rd = parseXML(await relFile.async("string"));
        const rels2 = all(rd.documentElement, "Relationship");
        const nr = rels2.find(r => (attr(r, "Type") || "").endsWith("/notesSlide"));
        if (nr) {
          const tgt = attr(nr, "Target");
          const np = ("ppt/slides/" + tgt).replace(/ppt\/slides\/\.\.\//, "ppt/");
          const nf = zip.file(np);
          if (nf) {
            const nstr = await nf.async("string");
            const ms = nstr.match(/<a:t>([\s\S]*?)<\/a:t>/g) || [];
            notes = ms.map(x => x.replace(/^<a:t>/, "").replace(/<\/a:t>$/, ""))
              .join("\n").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
          }
        }
      }

      slides.push({ bg: bgColor, elements, notes });
    }
    if (!slides.length) slides.push({ bg: "#ffffff", elements: [] });

    // ---------- PPTX 批注导入（ppt/comments/commentN.xml + ppt/commentAuthors.xml）----------
    const comments = [];
    // 作者表
    const authorNames = [];
    const authorsFile = zip.file("ppt/commentAuthors.xml");
    if (authorsFile) {
      try {
        const ad = parseXML(await authorsFile.async("string"));
        all(ad.documentElement, "cmAuthor").forEach(a => authorNames.push((a.getAttribute("name") || a.textContent || "").trim() || "作者"));
      } catch (e) {}
    }
    // 每页的批注文件 commentN.xml（N 从 1 开始）
    const commentFiles = {};
    Object.keys(zip.files).forEach(f => {
      const m = f.match(/^ppt\/comments\/comment(\d+)\.xml$/);
      if (m) commentFiles[+m[1]] = zip.file(f);
    });
    for (const [nStr, file] of Object.entries(commentFiles)) {
      const slideIdx = +nStr - 1;
      if (!file) continue;
      try {
        const cd = parseXML(await file.async("string"));
        all(cd.documentElement, "cm").forEach(cm => {
          const authorId = +(cm.getAttribute("authorId") || "0");
          // PPTX comment 文本存于 <p:text>（presentationml）
          let text = "";
          const textEl = cm.getElementsByTagNameNS ? cm.getElementsByTagNameNS("*", "text")[0] : null;
          if (textEl) text = textEl.textContent || "";
          else text = (cm.getElementsByTagName("text")[0]?.textContent) || "";
          // PPTX 批注位置（可选）
          let posX = 0, posY = 0;
          const posEl = first(cm, "pos");
          if (posEl) { posX = +(posEl.getAttribute("x") || "0"); posY = +(posEl.getAttribute("y") || "0"); }
          comments.push({
            id: "cmt" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
            slide: slideIdx,
            author: authorNames[authorId] || "作者",
            createdAt: Date.now(),
            resolved: false,
            text: text || "",
            replies: [],
            _pos: { x: posX, y: posY }
          });
        });
      } catch (e) { /* 不阻断导入 */ }
    }

    console.timeEnd("[PPTX] parsePptx 总耗时");
    return { type: "presentation", data: { slides, comments }, compat: "B", note: `PPTX 已导入 ${slides.length} 页（基础兼容：文本/图片/形状/位置/样式保留${comments.length ? "；批注 " + comments.length + " 条" : ""}）` };
  }

  function shapeText(sp) {
    const body = first(sp, "txBody");
    if (!body) return null;
    const ps = all(body, "p");
    const parts = ps.map(p => all(p, "t").map(t => t.textContent).join("")).filter(s => s !== "" || true);
    // 段落间换行，空段保留为换行
    const text = parts.join("\n").replace(/\s+$/g, "");
    return text || null;
  }
  function runStyle(sp, scale) {
    const txBody = first(sp, "txBody");
    if (!txBody) return {};
    const rPr = first(txBody, "rPr");
    const sz = rPr ? attr(rPr, "sz") : null;
    const fontSize = sz ? Math.round((+sz) / 100 * 12700 * (scale || 1)) : null;
    const b = rPr && (attr(rPr, "b") === "1" || first(rPr, "b"));
    const clr = rPr ? first(rPr, "srgbClr") : null;
    const color = clr ? "#" + attr(clr, "val") : null;
    const font = rPr ? (first(rPr, "latin") || first(rPr, "ea") || first(rPr, "cs")) : null;
    const fontFamily = font ? attr(font, "typeface") : null;
    const it = rPr && (attr(rPr, "i") === "1" || first(rPr, "i"));
    const firstP = first(txBody, "p");
    const pPr = firstP ? first(firstP, "pPr") : null;
    const algn = pPr ? attr(pPr, "algn") : null;
    const alignMap = { l: "left", ctr: "center", r: "right", just: "justify", dist: "justify" };
    const align = algn ? (alignMap[algn] || "left") : null;
    return { fontSize, color, bold: !!b, italic: !!it, fontFamily, align };
  }

  /* ============================================================
     ODF (odt / ods / odp) -> 对应模块
     ============================================================ */
  async function parseOdf(ext, zip) {
    const content = zip.file("content.xml");
    if (!content) throw new Error("ODF 缺少 content.xml");
    const d = parseXML(await content.async("string"));
    const body = first(d.documentElement, "body");
    if (!body) throw new Error("ODF 缺少 body");

    // 样式表（用于加粗/对齐判定）
    const styleMap = await buildOdfStyles(zip);

    if (first(body, "text")) return parseOdt(first(body, "text"), styleMap);
    if (first(body, "spreadsheet")) return parseOds(first(body, "spreadsheet"), styleMap);
    if (first(body, "presentation")) return parseOdp(first(body, "presentation"), styleMap);
    throw new Error("无法识别的 ODF 类型");
  }

  async function buildOdfStyles(zip) {
    const map = { para: {}, text: {} }; // name -> {bold, align}
    const files = ["styles.xml", "content.xml"].map(n => zip.file(n)).filter(Boolean);
    for (const f of files) {
      let d; try { d = parseXML(await f.async("string")); } catch (e) { continue; }
      all(d.documentElement, "style").forEach(st => {
        const name = attr(st, "style:name");
        if (!name) return;
        const tp = attr(st, "style:family");
        const props = first(st, "text-properties");
        const pprops = first(st, "paragraph-properties");
        const entry = {};
        if (props) {
          if (/bold/i.test(attr(props, "fo:font-weight") || "")) entry.bold = true;
          if (/italic/i.test(attr(props, "fo:font-style") || "")) entry.italic = true;
        }
        if (pprops) {
          const al = attr(pprops, "fo:text-align");
          if (al) entry.align = al;
        }
        if (tp === "paragraph") map.para[name] = entry;
        else map.text[name] = entry;
      });
    }
    return map;
  }

  function parseOdt(textEl, styleMap) {
    let html = "";
    let listBuf = null;
    const flushList = () => { if (listBuf) { html += `<${listBuf.type}>` + listBuf.items.map(i => `<li>${i}</li>`).join("") + `</${listBuf.type}>`; listBuf = null; } };

    const handleP = (p, listType) => {
      const styleName = attr(p, "text:style-name");
      const st = styleMap.para[styleName] || {};
      let inner = odfInline(p, styleMap);
      const align = st.align ? ` style="text-align:${st.align}"` : "";
      if (listType) {
        if (!listBuf || listBuf.type !== listType) { flushList(); listBuf = { type: listType, items: [] }; }
        listBuf.items.push(inner);
      } else { flushList(); html += `<p${align}>${inner || "<br>"}</p>`; }
    };

    for (const node of Array.from(textEl.children)) {
      const tag = node.localName;
      if (tag === "h") {
        const lvl = Math.min(6, Math.max(1, +attr(node, "text:outline-level") || 1));
        flushList(); html += `<h${lvl}>${odfInline(node, styleMap) || "<br>"}</h${lvl}>`;
      } else if (tag === "p") {
        handleP(node, null);
      } else if (tag === "list") {
        const listType = /number|ordered/i.test(attr(node, "text:style-name") || "") ? "ol" : "ul";
        all(node, "list-item").forEach(li => {
          const p = first(li, "p");
          if (p) handleP(p, listType);
        });
      } else if (tag === "table") {
        flushList(); html += odfTable(node, styleMap);
      }
    }
    flushList();
    return { type: "writer", data: { html: html || "<p>（空文档）</p>" }, compat: "B", note: "ODT 已导入（基本兼容：标题/段落/列表/表格保留）" };
  }

  function odfInline(el, styleMap) {
    let out = "";
    for (const n of Array.from(el.childNodes)) {
      if (n.nodeType === 3) { out += esc(n.nodeValue); continue; }
      const tag = n.localName;
      if (tag === "span") {
        const st = styleMap.text[attr(n, "text:style-name")] || {};
        let s = odfInline(n, styleMap);
        if (st.bold) s = `<strong>${s}</strong>`;
        if (st.italic) s = `<em>${s}</em>`;
        out += s;
      } else if (tag === "a") {
        out += `<a href="${escAttr(attr(n, "xlink:href") || "#")}">${odfInline(n, styleMap)}</a>`;
      } else if (tag === "line-break") out += "<br>";
      else if (tag === "tab") out += "    ";
      else out += odfInline(n, styleMap);
    }
    return out;
  }

  function odfTable(tbl, styleMap) {
    const rows = all(tbl, "table-row").map(tr => {
      const tds = all(tr, "table-cell").map(tc => {
        const rep = +attr(tc, "table:number-columns-repeated") || 1;
        const cell = `<td>${odfInline(tc, styleMap)}</td>`;
        return cell.repeat(rep);
      }).join("");
      return `<tr>${tds}</tr>`;
    }).join("");
    return `<table class="imp-table"><tbody>${rows}</tbody></table>`;
  }

  function parseOds(sheetEl, styleMap) {
    const table = first(sheetEl, "table") || sheetEl;
    const cells = {};
    let maxC = 1, maxR = 1;
    let r = 0;
    all(table, "table-row").forEach(row => {
      r++;
      let c = 0;
      all(row, "table-cell").forEach(td => {
        const rep = +attr(td, "table:number-columns-repeated") || 1;
        for (let k = 0; k < rep; k++) {
          c++;
          const vt = attr(td, "office:value-type");
          const val = vt === "string" ? all(td, "p").map(p => p.textContent).join("") : attr(td, "office:value");
          if (val !== undefined && val !== null && val !== "") {
            const ref = OS.FormulaEngine.idxToCol(c) + r;
            cells[ref] = { v: vt === "float" || vt === "percentage" || vt === "currency" ? Number(val) : val };
            maxC = Math.max(maxC, c); maxR = Math.max(maxR, r);
          }
        }
      });
    });
    return { type: "spreadsheet", data: { rows: Math.max(maxR, 50), cols: Math.max(maxC, 16), cells, styles: {} }, compat: "B", note: "ODS 已导入（基本兼容：单元格值与格式保留）" };
  }

  function parseOdp(presEl, styleMap) {
    const W = 760, H = 427;
    const cmToPx = W / 25.4; // 以 25.4cm 幻灯片宽近似映射到画布
    const slides = [];
    all(presEl, "page").forEach(page => {
      const bg = attr(page, "draw:background-color") || "#ffffff";
      const elements = [];
      all(page, "frame").forEach(fr => {
        const tb = first(fr, "text-box") || first(fr, "image");
        if (!tb) return;
        const text = all(tb, "p").map(p => all(p, "span").map(s => s.textContent).join("") || p.textContent).join("\n").trim();
        if (!text) return;
        const x = parseFloat(attr(fr, "svg:x")) || 1;
        const y = parseFloat(attr(fr, "svg:y")) || 1;
        const w = parseFloat(attr(fr, "svg:width")) || 5;
        const h = parseFloat(attr(fr, "svg:height")) || 3;
        elements.push({
          id: OS.util.uid("el"), type: "text",
          x: Math.round(x * cmToPx), y: Math.round(y * cmToPx),
          w: Math.max(40, Math.round(w * cmToPx)), h: Math.max(30, Math.round(h * cmToPx)),
          text, fontSize: 24, color:OS.theme.getVar("undefined"), bold: false
        });
      });
      slides.push({ bg, elements });
    });
    if (!slides.length) slides.push({ bg: "#ffffff", elements: [] });
    return { type: "presentation", data: { slides }, compat: "B", note: `ODP 已导入 ${slides.length} 页（基本兼容：文本/位置保留）` };
  }

  function firstZip(zip, prefix) {
    const name = Object.keys(zip.files).find(n => n.indexOf(prefix) === 0 && n.endsWith(".xml"));
    return name ? zip.file(name) : null;
  }

  /* ============================================================
     OFD (国标 GB/T 33190) -> Presentation 幻灯片
     - 包结构：OFD.xml -> Doc_N/Document.xml -> Pages/Page_N/Content.xml
     - 坐标系：原点页面左上角，X 右正 Y 下正，单位 mm（毫米）
     - 文本：<TextObject Boundary="x y w h"> -> <TextCode>文本内容</TextCode>
     ============================================================ */
  async function parseOfd(zip) {
    const W = 760, H = 427; // 演示画布尺寸（与 presentation.js 对齐）

    // 1) 主入口 OFD.xml -> DocRoot
    const ofdFile = zip.file("OFD.xml") || firstZip(zip, "OFD.xml");
    let docRoot = "Doc_0/Document.xml";
    if (ofdFile) {
      const od = parseXML(await ofdFile.async("string"));
      const dr = first(od.documentElement, "DocRoot");
      if (dr && dr.textContent.trim()) docRoot = dr.textContent.trim();
    }
    // docDir = DocRoot 所在目录（去掉文件名）
    const docDir = docRoot.replace(/[^/]+$/, "");
    const docFile = zip.file(docRoot) || zip.file(docDir + (docRoot.split("/").pop()));
    if (!docFile) throw new Error("OFD 缺少 Document.xml");

    const dd = parseXML(await docFile.async("string"));

    // 2) 文档默认页面尺寸（PhysicalBox，单位 mm）
    let pageW = 210, pageH = 297;
    const docBox = first(dd.documentElement, "PhysicalBox");
    if (docBox) { const b = (docBox.textContent || "").trim().split(/\s+/).map(Number); if (b.length === 4 && b[2] > 0 && b[3] > 0) { pageW = b[2]; pageH = b[3]; } }

    // 3) 页面列表（Page 的 BaseLoc 相对文档目录）
    const pages = all(dd.documentElement, "Page").map(p => {
      const bl = attr(p, "BaseLoc") || "";
      return bl ? (docDir + bl) : null;
    }).filter(Boolean);

    if (!pages.length) throw new Error("OFD 未找到页面");

    // 等比缩放，居中（letterbox），保持版式比例
    const scale = Math.min(W / pageW, H / pageH);
    const offX = (W - pageW * scale) / 2;
    const offY = (H - pageH * scale) / 2;
    const mm = v => (parseFloat(v) || 0) * scale;
    const toPxX = m => Math.round(offX + mm(m));
    const toPxY = m => Math.round(offY + mm(m));

    const slides = [];
    for (const path of pages) {
      const pf = zip.file(path);
      if (!pf) continue;
      const cd = parseXML(await pf.async("string"));
      // 单页尺寸优先于文档默认
      let pw = pageW, ph = pageH;
      const pageBox = first(cd.documentElement, "PhysicalBox");
      if (pageBox) { const b = (pageBox.textContent || "").trim().split(/\s+/).map(Number); if (b.length === 4 && b[2] > 0 && b[3] > 0) { pw = b[2]; ph = b[3]; } }
      const sc = pw === pageW && ph === pageH ? scale : Math.min(W / pw, H / ph);
      const ox = (W - pw * sc) / 2, oy = (H - ph * sc) / 2;

      const elements = [];
      all(cd.documentElement, "TextObject").forEach(to => {
        const bnd = (attr(to, "Boundary") || "0 0 20 10").trim().split(/\s+/).map(Number);
        const x = bnd[0] || 0, y = bnd[1] || 0, w = bnd[2] || 50, h = bnd[3] || 10;
        // TextCode 文本（可能多个，换行拼接）
        const texts = all(to, "TextCode").map(tc => (tc.textContent || "").replace(/\s+$/g, "")).filter(Boolean);
        const text = texts.join("\n");
        if (!text) return;
        const sizeMM = parseFloat(attr(to, "Size")) || 3.5; // OFD 字号单位 mm
        const weight = parseFloat(attr(to, "Weight"));
        const bold = (!isNaN(weight) && weight >= 0.4) || attr(to, "Bold") === "true";
        const italic = attr(to, "Italic") === "true";
        elements.push({
          id: OS.util.uid("el"), type: "text",
          x: Math.round(ox + x * sc), y: Math.round(oy + y * sc),
          w: Math.max(40, Math.round(w * sc)), h: Math.max(20, Math.round(h * sc)),
          text, fontSize: Math.max(10, Math.round(sizeMM * sc)), color:OS.theme.getVar("undefined"), bold: !!bold, italic: !!italic
        });
      });
      slides.push({ bg: "#ffffff", elements });
    }
    if (!slides.length) slides.push({ bg: "#ffffff", elements: [] });
    return { type: "presentation", data: { slides }, compat: "B", note: `OFD 已导入 ${slides.length} 页（基本兼容：文本按版式坐标定位；图形/图片为后续项）` };
  }

  /* ============================================================
     XMind（.xmind）→ mindmap 数据结构
     现代格式(zip 内 content.json)，旧版 XMind 8(zip 内 content.xml)
     ============================================================ */
  let _xmNodeId = 0;
  function xmUid() { return "xm_" + (++_xmNodeId) + "_" + Math.random().toString(36).slice(2, 8); }
  // JSON 格式（XMind 2020+）
  function xmJsonToNodes(rootTopic, nodes, parentId, depth) {
    if (!rootTopic) return;
    const id = xmUid();
    // title 可能是 string 或国际化对象 { zh_CN: "...", en_US: "..." }
    let rawTitle = rootTopic.title;
    if (rawTitle && typeof rawTitle !== "string") {
      // 国际化对象 — 取 zh_CN / en_US / 第一个值
      rawTitle = rawTitle.zh_CN || rawTitle.en_US || Object.values(rawTitle)[0] || "";
    }
    const text = (rawTitle || rootTopic.text || "").trim() || "未命名主题";
    const node = {
      id, x: 0, y: 0, text,
      color: depth === 0 ? "#1e3a5f" : "#2563eb",
      shape: "rounded", fontSize: depth === 0 ? 16 : 14,
      parent: parentId, isRoot: depth === 0
    };
    nodes.push(node);
    const children = (rootTopic.children && rootTopic.children.attached) || rootTopic.children || [];
    if (Array.isArray(children)) {
      children.forEach(ch => { if (ch && typeof ch === "object") xmJsonToNodes(ch, nodes, id, depth + 1); });
    }
  }
  // XML 格式（XMind 8）
  function xmXmlTopicToNode(el, nodes, parentId, depth) {
    const t = el.getElementsByTagName("title");
    const text = ((t && t[0] && t[0].textContent) || el.getAttribute("title") || "未命名主题").trim();
    const id = el.getAttribute("id") || xmUid();
    // 确保唯一（XMind 8 里 topic id 已唯一，但多 sheet 间不保证）
    const node = {
      id, x: 0, y: 0, text,
      color: depth === 0 ? "#1e3a5f" : "#2563eb",
      shape: "rounded", fontSize: depth === 0 ? 16 : 14,
      parent: parentId, isRoot: depth === 0
    };
    nodes.push(node);
    // 递归找子 topic
    const allChildren = el.getElementsByTagName("children");
    for (let i = 0; i < allChildren.length; i++) {
      const topicsList = allChildren[i].getElementsByTagName("topics");
      for (let j = 0; j < topicsList.length; j++) {
        const childTopics = topicsList[j].getElementsByTagName("topic");
        for (let k = 0; k < childTopics.length; k++) {
          // 只处理直接子节点（避免重复拿后代）
          const parentCheck = childTopics[k].parentElement;
          if (parentCheck && parentCheck.tagName.toLowerCase() === "topics") {
            xmXmlTopicToNode(childTopics[k], nodes, id, depth + 1);
          }
        }
      }
    }
  }
  async function parseXmind(zip) {
    const jf = zip.file("content.json");
    const xf = zip.file("content.xml");
    const nodes = [];
    let rootId = null;
    if (jf) {
      const root = JSON.parse(await jf.async("string"));
      const sheets = Array.isArray(root) ? root
        : (root && root.sheet ? root.sheet : null);
      const list = sheets || [{ title: (root && root.title) || "思维导图", rootTopic: root && root.rootTopic }];
      // 只取第一个 sheet 的第一个 rootTopic 作为根
      const firstSheet = Array.isArray(list) ? list[0] : list;
      const rt = firstSheet && firstSheet.rootTopic;
      if (rt) {
        const rootJsonId = xmUid();
        nodes.push({ id: rootJsonId, x: 0, y: 0, text: (rt.title || "中心主题").trim(), color: "#1e3a5f", shape: "rounded", fontSize: 16, parent: null, isRoot: true });
        rootId = rootJsonId;
        const children = (rt.children && rt.children.attached) || rt.children || [];
        if (Array.isArray(children)) children.forEach(ch => xmJsonToNodes(ch, nodes, rootJsonId, 1));
      }
    } else if (xf) {
      const doc = parseXML(await xf.async("string"));
      const sheets = doc.getElementsByTagName("sheet");
      if (sheets && sheets.length) {
        const firstSheet = sheets[0];
        // 直接子 topic（根节点）
        const childTopics = firstSheet.getElementsByTagName("topic");
        if (childTopics && childTopics.length) {
          // 拿第一个（XML 里 topic 可能嵌套，先找直接挂在 sheet 下的）
          let rootTopic = null;
          for (let i = 0; i < childTopics.length; i++) {
            const parent = childTopics[i].parentElement;
            if (parent && parent.tagName.toLowerCase() === "sheet") { rootTopic = childTopics[i]; break; }
          }
          if (!rootTopic) rootTopic = childTopics[0];
          if (rootTopic) {
            xmXmlTopicToNode(rootTopic, nodes, null, 0);
            rootId = nodes[0].id;
          }
        }
      }
    }
    if (!nodes.length) throw new Error("无法解析的 XMind 文件（缺少 content.json / content.xml）");
    // 🔥 post-parse 防御：清理悬空 parent + 校验 rootId
    const allIds = new Set(nodes.map(n => n.id));
    let dangling = 0;
    nodes.forEach(n => { if (n.parent && !allIds.has(n.parent)) { n.parent = null; dangling++; } });
    if (!allIds.has(rootId)) rootId = nodes.find(n => !n.parent)?.id || nodes[0]?.id;
    if (dangling > 0 || !rootId) console.warn('[XMIND-parse] 修正了', dangling, '个悬空 parent，rootId=', rootId);
    return { type: "mindmap", data: { mode: "map", nodes, edges: [], rootId }, compat: "B", note: `XMind 已导入（${nodes.length} 个节点，仅首个 sheet）` };
  }

  /* ============================================================
     入口
     ============================================================ */
  /* ============================================================
     BIFF8 .xls (旧版 Excel 二进制) — 用 SheetJS 解析
     ============================================================ */
  function parseXls(buf) {
    if (!XLSX) throw new Error("未加载 SheetJS（xlsx）库");
    const wb = XLSX.read(buf, { type: "array", cellFormula: true, cellText: false, cellDates: false });
    const sheetName = wb.SheetNames[0] || "Sheet1";
    const ws = wb.Sheets[sheetName];
    if (!ws) throw new Error("XLS 工作簿为空");
    // 用 sheet_to_json 拉二维数组（含公式）
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "", raw: false });
    const cells = {};
    let maxR = rows.length, maxC = 0;
    rows.forEach((row, ri) => {
      row.forEach((val, ci) => {
        const ref = XLSX.utils.encode_cell({ r: ri, c: ci });
        maxC = Math.max(maxC, ci + 1);
        if (val === null || val === undefined || val === "") return;
        if (typeof val === "string" && val.startsWith("=")) {
          cells[ref] = { f: val };
        } else {
          cells[ref] = { v: typeof val === "number" ? val : String(val) };
        }
      });
    });
    const note = "XLS 已导入（基本兼容：值与公式保留；仅导入首个工作表）";
    return { type: "spreadsheet", data: { rows: Math.max(maxR, 50), cols: Math.max(maxC, 16), cells, styles: {} }, compat: "B", note };
  }

  /* ============================================================
     入口
     ============================================================ */
  async function importFile(file, onProgress) { console.time("[IMPORT-OOXML]");
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    let buf;
    try {
      buf = new Uint8Array(await withTimeout(file.arrayBuffer(), 5000, "读取文件 " + file.name));
    } catch (e) { throw new Error("读取文件失败：" + e.message); }
    if (onProgress) onProgress("读取文件字节", 0.2);
    // .xls 是 BIFF8 二进制，不走 JSZip，直接 SheetJS 解析
    if (ext === "xls") {
      if (!XLSX) { XLSX = await OS.LazyLib.load("XLSX"); }
      if (onProgress) onProgress("解析旧版 Excel (.xls)", 0.7);
      const r = parseXls(buf);
      if (onProgress) onProgress("构建文档模型", 0.95);
      return r;
    }
    // 其他格式（docx/xlsx/pptx/odt/ods/odp/ofd/xmind）都是 ZIP 容器
    if (!JSZip) throw new Error("需加载 JSZip 解析库");
    let zip;
    try {
      zip = await withTimeout(JSZip.loadAsync(buf.buffer), 30000, "JSZip.loadAsync(" + file.name + ")");
    } catch (e) { throw new Error("解压 ZIP 失败：" + e.message); }
    if (onProgress) onProgress("解压包结构", 0.5);
    let r;
    try {
      switch (ext) {
        case "docx": if (onProgress) onProgress("解析 Word 文档", 0.7); r = parseDocx(zip); break;
        case "xlsx": if (onProgress) onProgress("解析工作簿", 0.7); r = parseXlsx(zip); break;
        case "pptx": if (onProgress) onProgress("解析演示文稿", 0.7); r = parsePptx(zip); break;
        case "odt":
        case "ods":
        case "odp": if (onProgress) onProgress("解析 ODF 文档", 0.7); r = parseOdf(ext, zip); break;
        case "ofd": if (onProgress) onProgress("解析 OFD 版式文件", 0.7); r = parseOfd(zip); break;
        case "xmind": if (onProgress) onProgress("解析思维导图 XMind", 0.7); r = await withTimeout(parseXmind(zip), 15000, "parseXmind(" + file.name + ")"); break;
        default: r = null;
      }
    } catch (e) { throw new Error("解析 " + file.name + " 失败：" + e.message); }
    if (onProgress) onProgress("构建文档模型", 0.95);
    return r;
  }

  OS.Importer = { importFile, parseDocx, parseXlsx, parsePptx, parseXmind };
  if (OS.util && OS.util.log) OS.util.log("Importer(OOML/ODF) ready");
})(window);
